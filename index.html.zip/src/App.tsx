import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Car, User, ArrowRight, Download, ShieldCheck, HelpCircle, 
  MapPin, Star, Sparkles, Navigation, Smartphone, Check, SmartphoneIcon, Menu, X, Globe
} from 'lucide-react';

import { RegisteredDriver, RegisteredPassenger } from './types';
import { Language, translations } from './translations';
import Logo from './components/Logo';
import HeroSection from './components/HeroSection';
import FeatureGrid from './components/FeatureGrid';
import RegistrationForm from './components/RegistrationForm';
import FaqSection from './components/FaqSection';
import AdminDashboard from './components/AdminDashboard';

// Local storage synchronization keys
const LOCAL_DRIVERS_KEY = 'atlasride_drivers';
const LOCAL_PASSENGERS_KEY = 'atlasride_passengers';
const LOCAL_LANG_KEY = 'atlasride_lang';

const initialMockDrivers: RegisteredDriver[] = [
  {
    id: 'd-mock-1',
    name: 'Alexander Wright',
    email: 'alex.wright@atlasride-driver.com',
    phone: '+1 (555) 765-4321',
    city: 'San Francisco',
    vehicleType: 'premium',
    vehicleModel: 'Tesla Model 3 (2023)',
    licensePlate: 'LV-777-XP',
    licenseNumber: 'DL-CA839257',
    registeredAt: '5/18/2026, 10:14:02 AM',
    status: 'approved'
  },
  {
    id: 'd-mock-2',
    name: 'Sarah Jenkins',
    email: 'jenkins.s@fastmail.com',
    phone: '+1 (555) 902-1248',
    city: 'Austin',
    vehicleType: 'economy',
    vehicleModel: 'Toyota Camry (2020)',
    licensePlate: 'TX-43-WQA',
    licenseNumber: 'DL-TX129845',
    registeredAt: '5/20/2026, 3:45:10 PM',
    status: 'pending_review'
  }
];

const initialMockPassengers: RegisteredPassenger[] = [
  {
    id: 'p-mock-1',
    name: 'Elena Rostova',
    email: 'elena.rostova@gmail.com',
    phone: '+1 (555) 321-9876',
    preferredPayment: 'card',
    referralCode: 'GOLDEN50',
    registeredAt: '5/19/2026, 11:30:15 AM',
    status: 'active'
  },
  {
    id: 'p-mock-2',
    name: 'Marcus Vance',
    email: 'm.vance@techcorp.io',
    phone: '+1 (555) 123-4567',
    preferredPayment: 'mobile_wallet',
    registeredAt: '5/20/2026, 8:12:44 AM',
    status: 'active'
  }
];

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem(LOCAL_LANG_KEY);
    return (saved === 'en' || saved === 'fr' || saved === 'ar') ? saved : 'en';
  });

  const [drivers, setDrivers] = useState<RegisteredDriver[]>([]);
  const [passengers, setPassengers] = useState<RegisteredPassenger[]>([]);
  const [formInitialTab, setFormInitialTab] = useState<'driver' | 'passenger'>('passenger');
  const [activeFormRefresh, setActiveFormRefresh] = useState<number>(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  const t = translations[lang];
  const isRtl = t.dir === 'rtl';

  // Apply language direction to the html document element globally
  useEffect(() => {
    document.documentElement.dir = t.dir;
    document.documentElement.lang = lang;
    localStorage.setItem(LOCAL_LANG_KEY, lang);
  }, [lang, t.dir]);

  // Load submissions from localStorage once on boot
  useEffect(() => {
    const rawDrivers = localStorage.getItem(LOCAL_DRIVERS_KEY);
    const rawPassengers = localStorage.getItem(LOCAL_PASSENGERS_KEY);

    if (rawDrivers) {
      try {
        setDrivers(JSON.parse(rawDrivers));
      } catch (e) {
        setDrivers(initialMockDrivers);
      }
    } else {
      setDrivers(initialMockDrivers);
      localStorage.setItem(LOCAL_DRIVERS_KEY, JSON.stringify(initialMockDrivers));
    }

    if (rawPassengers) {
      try {
        setPassengers(JSON.parse(rawPassengers));
      } catch (e) {
        setPassengers(initialMockPassengers);
      }
    } else {
      setPassengers(initialMockPassengers);
      localStorage.setItem(LOCAL_PASSENGERS_KEY, JSON.stringify(initialMockPassengers));
    }
  }, []);

  // Save changes to localStorage on state changes
  const saveDrivers = (newDrivers: RegisteredDriver[]) => {
    setDrivers(newDrivers);
    localStorage.setItem(LOCAL_DRIVERS_KEY, JSON.stringify(newDrivers));
  };

  const savePassengers = (newPassengers: RegisteredPassenger[]) => {
    setPassengers(newPassengers);
    localStorage.setItem(LOCAL_PASSENGERS_KEY, JSON.stringify(newPassengers));
  };

  // State actions
  const handleRegisterDriver = (driver: RegisteredDriver) => {
    const updated = [driver, ...drivers];
    saveDrivers(updated);
  };

  const handleRegisterPassenger = (passenger: RegisteredPassenger) => {
    const updated = [passenger, ...passengers];
    savePassengers(updated);
  };

  const handleApproveDriver = (id: string) => {
    const updated = drivers.map(drv => {
      if (drv.id === id) {
        return { ...drv, status: 'approved' as const };
      }
      return drv;
    });
    saveDrivers(updated);
  };

  const handleDeleteDriver = (id: string) => {
    const updated = drivers.filter(drv => drv.id !== id);
    saveDrivers(updated);
  };

  const handleDeletePassenger = (id: string) => {
    const updated = passengers.filter(pas => pas.id !== id);
    savePassengers(updated);
  };

  const handleClearAll = () => {
    saveDrivers(initialMockDrivers);
    savePassengers(initialMockPassengers);
  };

  const handleScrollToSection = (sectionId: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRegisterCta = (tab: 'driver' | 'passenger') => {
    setFormInitialTab(tab);
    // Reset key to trigger form update correctly
    setActiveFormRefresh(prev => prev + 1);
    
    // Perform smooth scroll to registration card anchor
    setTimeout(() => {
      const container = document.getElementById('register-section');
      if (container) {
        container.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  return (
    <div className={`min-h-screen bg-zinc-100 font-sans text-zinc-800 antialiased flex flex-col ${isRtl ? 'text-right' : 'text-left'}`}>
      
      {/* Monochrome Premium Header Nav Bar */}
      <header className="sticky top-0 z-50 bg-zinc-100/90 backdrop-blur-md border-b border-zinc-200">
        <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between ${isRtl ? 'flex-row-reverse' : ''}`}>
          
          {/* Logo brand (Custom design matching uploaded image) */}
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="group cursor-pointer"
          >
            <Logo isDark={false} isRtl={isRtl} className="transition-all duration-300 group-hover:scale-105" />
          </button>

          {/* Desktop Nav Actions */}
          <nav className={`hidden lg:flex items-center gap-8 text-sm ${isRtl ? 'flex-row-reverse' : ''}`}>
            {[
              { label: t.header.features, target: 'features' },
              { label: t.header.register, target: 'register-section' },
              { label: t.header.faq, target: 'faq' }
            ].map((link) => (
              <button
                key={link.target}
                onClick={() => handleScrollToSection(link.target)}
                className="text-zinc-650 hover:text-black transition font-semibold cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Download & Actions Panel */}
          <div className={`hidden md:flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
            
            {/* Language Switcher */}
            <div className={`p-0.5 bg-white border border-zinc-250 rounded-xl inline-flex text-xs shadow-sm ${isRtl ? 'flex-row-reverse' : ''}`}>
              {(['en', 'fr', 'ar'] as const).map((curr) => (
                <button
                  key={curr}
                  onClick={() => setLang(curr)}
                  className={`px-2.5 py-1.5 rounded-lg font-bold font-sans uppercase cursor-pointer transition ${
                    lang === curr
                      ? 'bg-zinc-900 text-white font-extrabold shadow-sm'
                      : 'text-zinc-500 hover:text-black'
                  }`}
                >
                  {curr}
                </button>
              ))}
            </div>

            <a
              href="https://play.google.com/store"
              target="_blank"
              rel="noreferrer"
              id="header-play-download"
              className={`flex items-center gap-2 bg-black hover:bg-zinc-900 text-white font-semibold text-xs px-4 py-2.5 rounded-xl transition ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <Download className="h-3.5 w-3.5 text-white animate-pulse" />
              <span>{t.header.getApp}</span>
            </a>
          </div>

          {/* Mobile Screen Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 lg:hidden text-zinc-700 hover:text-black rounded-lg hover:bg-zinc-200 transition"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

        </div>

        {/* Mobile slide drawer */}
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`lg:hidden border-t border-zinc-200 bg-zinc-50 border-b shadow-lg p-4 space-y-4 ${isRtl ? 'text-right' : 'text-left'}`}
          >
            {/* Language selections row on mobile */}
            <div className={`flex items-center gap-3 pb-2 border-b border-zinc-200 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Globe className="h-4 w-4 text-zinc-650" />
              <span className="text-xs text-zinc-700 font-semibold">{lang === 'ar' ? 'اختر اللغة:' : lang === 'fr' ? 'Sélecteur de langue:' : 'Language Selector:'}</span>
              <div className={`p-0.5 bg-white border border-zinc-255 rounded-lg inline-flex text-xs ${isRtl ? 'flex-row-reverse' : ''}`}>
                {(['en', 'fr', 'ar'] as const).map((curr) => (
                  <button
                    key={curr}
                    onClick={() => setLang(curr)}
                    className={`px-3 py-1 rounded text-xs font-bold uppercase transition ${
                      lang === curr ? 'bg-zinc-900 text-white shadow-sm' : 'text-zinc-600'
                    }`}
                  >
                    {curr}
                  </button>
                ))}
              </div>
            </div>

            {[
              { label: t.header.features, target: 'features' },
              { label: t.header.register, target: 'register-section' },
              { label: t.header.faq, target: 'faq' }
            ].map((link) => (
              <button
                key={link.target}
                onClick={() => handleScrollToSection(link.target)}
                className="w-full text-start p-3 text-zinc-750 hover:text-black hover:bg-zinc-200 rounded-xl block text-sm font-semibold transition"
              >
                {link.label}
              </button>
            ))}
            
            <a
              href="https://play.google.com/store"
              target="_blank"
              rel="noreferrer"
              id="mobile-header-play-download"
              className={`flex items-center justify-center gap-2 bg-black hover:bg-zinc-900 text-white font-bold text-sm w-full py-3 rounded-xl transition ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <Download className="h-4 w-4 text-white" />
              <span>{t.header.getApp} (Play Store)</span>
            </a>
          </motion.div>
        )}
      </header>

      {/* Main Content Layout */}
      <main className="flex-grow">
        
        {/* Hero Area */}
        <HeroSection onScrollToRegister={handleRegisterCta} t={t} lang={lang} />

        {/* Feature Grid area */}
        <FeatureGrid t={t} lang={lang} />

        {/* Registrations Form Hub */}
        <div key={`${formInitialTab}-${activeFormRefresh}`}>
          <RegistrationForm 
            onRegisterDriver={handleRegisterDriver}
            onRegisterPassenger={handleRegisterPassenger}
            initialTab={formInitialTab}
            t={t}
            lang={lang}
          />
        </div>

        {/* Support FAQ accordion list */}
        <FaqSection t={t} lang={lang} />

        {/* Administrative Inspector Table */}
        <AdminDashboard
          drivers={drivers}
          passengers={passengers}
          onApproveDriver={handleApproveDriver}
          onDeleteDriver={handleDeleteDriver}
          onDeletePassenger={handleDeletePassenger}
          onClearAll={handleClearAll}
          t={t}
          lang={lang}
        />

      </main>

      {/* Styled Footers layout */}
      <footer className="bg-zinc-900 border-t border-zinc-800 text-zinc-400 py-16 px-4">
        <div className={`max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12 ${isRtl ? 'text-right' : 'text-left'}`}>
          
          {/* Brand Col */}
          <div className="md:col-span-4 space-y-4">
            <Logo isDark={true} isRtl={isRtl} />
            <p className="text-xs text-zinc-400 leading-relaxed font-light">
              {t.footer.desc}
            </p>
            <p className="text-xs text-zinc-500 font-mono">
              {t.footer.version}
            </p>
          </div>

          {/* Links 1 */}
          <div className="md:col-span-3 space-y-3 text-xs">
            <h4 className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest font-bold">{t.footer.linksPaths}</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleRegisterCta('passenger')} className="text-zinc-400 hover:text-white transition cursor-pointer">
                  {t.footer.btnRiderApp}
                </button>
              </li>
              <li>
                <button onClick={() => handleRegisterCta('driver')} className="text-zinc-400 hover:text-white transition cursor-pointer">
                  {t.footer.btnDriverApp}
                </button>
              </li>
              <li>
                <a href="#features" className="text-zinc-400 hover:text-white transition">
                  {t.footer.payScales}
                </a>
              </li>
              <li>
                <a href="#faq" className="text-zinc-405 hover:text-white transition">
                  {t.footer.onRoadGuides}
                </a>
              </li>
            </ul>
          </div>

          {/* Links 2 */}
          <div className="md:col-span-2 space-y-3 text-xs">
            <h4 className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest font-bold">{t.footer.linksLegal}</h4>
            <ul className="space-y-2 text-zinc-400 font-light">
              <li><a href="#" className="hover:text-white transition">{t.footer.terms}</a></li>
              <li><a href="#" className="hover:text-white transition">{t.footer.safeGuarantee}</a></li>
              <li><a href="#" className="hover:text-white transition">{t.footer.privacyCookie}</a></li>
              <li><a href="#" className="hover:text-white transition">{t.footer.regulatory}</a></li>
            </ul>
          </div>

          {/* Download CTAs */}
          <div className="md:col-span-3 space-y-4 text-xs">
            <h4 className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest font-bold">{t.footer.nativeCta}</h4>
            <p className="text-xs text-zinc-400 leading-normal">
              {t.footer.nativeDesc}
            </p>
            <div className="flex flex-col gap-2">
              <a 
                href="https://play.google.com/store" 
                target="_blank" 
                rel="noreferrer"
                id="footer-play-store-download"
                className={`flex items-center gap-3 bg-black hover:bg-zinc-950 border border-zinc-800 text-white p-3 rounded-xl transition duration-200 cursor-pointer ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}
              >
                <Download className="h-5 w-5 text-zinc-400" />
                <div className="font-sans">
                  <p className="text-[9px] font-mono text-zinc-500 leading-none uppercase">Get it on</p>
                  <p className="text-xs font-semibold leading-normal mt-0.5">Google Play</p>
                </div>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom copyright line */}
        <div className={`max-w-7xl mx-auto border-t border-zinc-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <p>{t.footer.copyright}</p>
          <div className="flex gap-4">
            <span className="hover:text-zinc-400 transition select-none">{t.footer.securityBadge}</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
