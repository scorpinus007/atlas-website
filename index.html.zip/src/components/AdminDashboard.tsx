import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, ShieldCheck, ShieldAlert, Award, 
  Trash2, User, Car, CheckCircle, RefreshCcw, Eye, ArrowUpDown, Lock
} from 'lucide-react';
import { RegisteredDriver, RegisteredPassenger } from '../types';
import { TranslationDict, Language } from '../translations';

interface AdminDashboardProps {
  drivers: RegisteredDriver[];
  passengers: RegisteredPassenger[];
  onApproveDriver: (id: string) => void;
  onDeleteDriver: (id: string) => void;
  onDeletePassenger: (id: string) => void;
  onClearAll: () => void;
  t: TranslationDict;
  lang: Language;
}

export default function AdminDashboard({
  drivers,
  passengers,
  onApproveDriver,
  onDeleteDriver,
  onDeletePassenger,
  onClearAll,
  t,
  lang
}: AdminDashboardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeCatalog, setActiveCatalog] = useState<'drivers' | 'passengers'>('drivers');

  const isRtl = t.dir === 'rtl';

  return (
    <section className="bg-zinc-200 border-t border-zinc-300 text-zinc-900 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        
        {/* Visual toggle header */}
        <div className={`flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 ${isRtl ? 'sm:flex-row-reverse text-right' : 'text-left'}`}>
          <div className="space-y-1">
            <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Database className="h-5 w-5 text-zinc-600" />
              <h3 className="font-display font-bold text-lg text-zinc-950">{t.admin.title}</h3>
            </div>
            <p className="text-xs text-zinc-750 font-sans font-medium">
              {t.admin.desc}
            </p>
          </div>

          <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            {isOpen && (
              <button
                onClick={onClearAll}
                className="flex items-center gap-1 bg-white hover:bg-zinc-100 text-zinc-800 border border-zinc-350 text-xs font-semibold px-3.5 py-2 rounded-xl transition duration-200 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                {t.admin.btnReset}
              </button>
            )}

            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`flex items-center gap-2 bg-black hover:bg-zinc-900 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition duration-250 cursor-pointer ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <Eye className="h-4 w-4 text-zinc-350" />
              <span>{isOpen ? t.admin.btnInspectorClose : t.admin.btnInspectorOpen}</span>
              <span className="bg-zinc-150 text-black font-mono font-bold text-[10px] px-2 py-0.5 rounded-full border border-zinc-300 shadow-inner">
                {drivers.length + passengers.length}
              </span>
            </button>
          </div>
        </div>

        {/* Collapsible content */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="bg-white rounded-2xl border border-zinc-300 p-6 mt-4 relative shadow-lg text-zinc-800">
                
                {/* Catalog Tab toggle */}
                <div className={`flex items-center justify-between border-b border-zinc-250 pb-4 mb-6 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <button
                      onClick={() => setActiveCatalog('drivers')}
                      className={`px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
                        activeCatalog === 'drivers' 
                          ? 'bg-black text-white shadow-md' 
                          : 'text-zinc-650 hover:text-black hover:bg-zinc-100/50'
                      }`}
                    >
                      {t.admin.tabDrivers} ({drivers.length})
                    </button>
                    <button
                      onClick={() => setActiveCatalog('passengers')}
                      className={`px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
                        activeCatalog === 'passengers' 
                          ? 'bg-black text-white shadow-md' 
                          : 'text-zinc-650 hover:text-black hover:bg-zinc-100/50'
                      }`}
                    >
                      {t.admin.tabPassengers} ({passengers.length})
                    </button>
                  </div>

                  <span className={`text-[10px] font-mono text-zinc-600 flex items-center gap-1 select-none ${isRtl ? 'flex-row-reverse' : ''}`}>
                    <Lock className="h-3 w-3 text-zinc-500" />
                    {t.admin.sandboxed}
                  </span>
                </div>

                {/* Database tables lists */}
                {activeCatalog === 'drivers' ? (
                  <div className="overflow-x-auto">
                    {drivers.length === 0 ? (
                      <div className="text-center py-12 text-zinc-500 font-sans text-sm">
                        <Car className="h-8 w-8 mx-auto text-zinc-400 mb-2.5" />
                        {t.admin.noDrivers}
                      </div>
                    ) : (
                      <table className={`w-full text-xs font-sans min-w-[700px] ${isRtl ? 'text-right' : 'text-left'}`}>
                        <thead>
                          <tr className={`border-b border-zinc-200 text-zinc-600 font-semibold uppercase tracking-wider text-[10px] ${isRtl ? 'text-right' : 'text-left'}`}>
                            <th className="pb-3">{t.admin.colName}</th>
                            <th className="pb-3">{t.admin.colContact}</th>
                            <th className="pb-3">{t.admin.colLocation}</th>
                            <th className="pb-3">{t.admin.colModel}</th>
                            <th className="pb-3 text-center">{t.admin.colStatus}</th>
                            <th className={`pb-3 ${isRtl ? 'text-left' : 'text-right'}`}>{t.admin.colActions}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-200 font-light text-zinc-850">
                          {drivers.map((drv) => (
                            <tr key={drv.id} className="hover:bg-zinc-100/50 transition">
                              <td className="py-4">
                                <div className="font-semibold text-zinc-950">{drv.name}</div>
                                <div className="text-[10px] text-zinc-500 font-mono mt-0.5">{drv.id}</div>
                              </td>
                              <td className="py-4 font-mono">
                                <div className="font-medium text-zinc-950">{drv.phone}</div>
                                <div className="text-zinc-600 mt-0.5">{drv.email}</div>
                              </td>
                              <td className="py-4">
                                <div className="font-medium text-zinc-900">{drv.city}</div>
                                <div className="text-[10px] text-zinc-600 uppercase font-mono mt-0.5">{drv.vehicleType}</div>
                              </td>
                              <td className="py-4 font-mono text-[10px]">
                                <div className="text-zinc-800 font-bold">{drv.vehicleModel}</div>
                                <div className="text-zinc-600 mt-0.5">{drv.licensePlate} / {drv.licenseNumber}</div>
                              </td>
                              <td className="py-4 text-center">
                                {drv.status === 'approved' ? (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-900 text-white text-[10px] font-semibold">
                                    <CheckCircle className="h-3 w-3 text-white" />
                                    {t.admin.statusApproved}
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-100 text-zinc-605 border border-zinc-250 text-[10px] font-semibold">
                                    <ShieldAlert className="h-3 w-3 text-zinc-500 animate-pulse" />
                                    {t.admin.statusPending}
                                  </span>
                                )}
                              </td>
                              <td className="py-4">
                                <div className={`flex items-center gap-2 ${isRtl ? 'justify-start' : 'justify-end'}`}>
                                  {drv.status === 'pending_review' && (
                                    <button
                                      onClick={() => onApproveDriver(drv.id)}
                                      className="bg-black hover:bg-zinc-900 text-white px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer border border-zinc-800"
                                      title="Approve driver application"
                                    >
                                      {t.admin.btnApprove}
                                    </button>
                                  )}
                                  <button
                                    onClick={() => onDeleteDriver(drv.id)}
                                    className="p-1.5 text-zinc-505 hover:text-red-600 transition cursor-pointer"
                                    title="Delete application"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    {passengers.length === 0 ? (
                      <div className="text-center py-12 text-zinc-500 font-sans text-sm">
                        <User className="h-8 w-8 mx-auto text-zinc-400 mb-2.5" />
                        {t.admin.noPassengers}
                      </div>
                    ) : (
                      <table className={`w-full text-xs font-sans min-w-[650px] ${isRtl ? 'text-right' : 'text-left'}`}>
                        <thead>
                          <tr className={`border-b border-zinc-200 text-zinc-600 font-semibold uppercase tracking-wider text-[10px] ${isRtl ? 'text-right' : 'text-left'}`}>
                            <th className="pb-3">{lang === 'ar' ? 'مسافر / راكب معتمد' : 'Passenger / ID'}</th>
                            <th className="pb-3">{t.admin.colContact}</th>
                            <th className="pb-3">{lang === 'ar' ? 'طريقة الدفع' : 'Payment Channel'}</th>
                            <th className="pb-3">{lang === 'ar' ? 'رمز دعوة الإحالة' : 'Referral Code'}</th>
                            <th className="pb-3 text-center">{lang === 'ar' ? 'الحالة' : 'Status'}</th>
                            <th className={`pb-3 ${isRtl ? 'text-left' : 'text-right'}`}>{t.admin.colActions}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-200 font-light text-zinc-850">
                          {passengers.map((pas) => (
                            <tr key={pas.id} className="hover:bg-zinc-100/50 transition">
                              <td className="py-4">
                                <div className="font-semibold text-zinc-950">{pas.name}</div>
                                <div className="text-[10px] text-zinc-500 font-mono mt-0.5">{pas.id}</div>
                              </td>
                              <td className="py-4 font-mono">
                                <div className="font-semibold text-zinc-950">{pas.phone}</div>
                                <div className="text-zinc-605 mt-0.5">{pas.email}</div>
                              </td>
                              <td className="py-4 font-mono uppercase text-[10px] text-zinc-800 font-semibold">
                                {pas.preferredPayment.replace('_', ' ')}
                              </td>
                              <td className="py-4 text-zinc-800 font-mono text-[11px]">
                                {pas.referralCode ? (
                                  <span className="text-zinc-950 font-bold">{pas.referralCode}</span>
                                ) : (
                                  <span className="text-zinc-500 font-normal">None Used</span>
                                )
                                }
                              </td>
                              <td className="py-4 text-center">
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-zinc-900 text-white text-[10px] font-semibold animate-pulse">
                                  <CheckCircle className="h-3 w-3 text-white" />
                                  {t.admin.statusVerifiedRider}
                                </span>
                              </td>
                              <td className="py-4">
                                <div className={`flex items-center gap-2 ${isRtl ? 'justify-start' : 'justify-end'}`}>
                                  <button
                                    onClick={() => onDeletePassenger(pas.id)}
                                    className="p-1.5 text-zinc-505 hover:text-red-00 transition cursor-pointer"
                                    title="Delete passenger"
                                  >
                                    <Trash2 className="h-3.5 w-3.5 text-zinc-500 hover:text-red-600" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                )}

              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
