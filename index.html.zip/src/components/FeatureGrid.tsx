import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  DollarSign, Map, ShieldAlert, CreditCard, 
  Hourglass, Sliders, TrendingUp, Compass, 
  Clock, ShieldCheck, HeartHandshake, HelpCircle 
} from 'lucide-react';
import { TranslationDict, Language } from '../translations';

interface FeatureGridProps {
  t: TranslationDict;
  lang: Language;
}

export default function FeatureGrid({ t, lang }: FeatureGridProps) {
  const [activeTab, setActiveTab] = useState<'passenger' | 'driver'>('passenger');
  const isRtl = t.dir === 'rtl';

  const passengerIcons = [
    <DollarSign className="h-6 w-6 text-zinc-900" />,
    <Map className="h-6 w-6 text-zinc-900" />,
    <ShieldAlert className="h-6 w-6 text-zinc-900" />,
    <CreditCard className="h-6 w-6 text-zinc-900" />,
    <Hourglass className="h-6 w-6 text-zinc-900" />,
    <Sliders className="h-6 w-6 text-zinc-900" />
  ];

  const driverIcons = [
    <TrendingUp className="h-6 w-6 text-zinc-900" />,
    <Clock className="h-6 w-6 text-zinc-900" />,
    <Compass className="h-6 w-6 text-zinc-900" />,
    <ShieldCheck className="h-6 w-6 text-zinc-900" />,
    <DollarSign className="h-6 w-6 text-zinc-900" />,
    <HeartHandshake className="h-6 w-6 text-zinc-900" />
  ];

  const activeIcons = activeTab === 'passenger' ? passengerIcons : driverIcons;
  const activeItems = activeTab === 'passenger' ? t.features.passengerItems : t.features.driverItems;

  return (
    <section id="features" className="py-20 bg-white text-slate-900 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Headline section */}
        <div className={`max-w-3xl mx-auto mb-16 ${isRtl ? 'text-right' : 'text-center'}`}>
          <div className="flex justify-center mb-4">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-zinc-800 bg-zinc-100 border border-zinc-200 px-3 py-1 rounded-full">
              {t.features.badge}
            </span>
          </div>
          <h2 className="font-display text-4xl font-extrabold tracking-tight text-zinc-950">
            {t.features.title}
          </h2>
          <p className="text-zinc-600 mt-4 leading-relaxed font-light">
            {t.features.subtitle}
          </p>

          {/* Toggle Tab */}
          <div className="mt-8 flex justify-center">
            <div className={`p-1.5 bg-zinc-100 border border-zinc-200/80 rounded-2xl shadow-inner flex ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
              <button
                onClick={() => setActiveTab('passenger')}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 cursor-pointer ${
                  activeTab === 'passenger' 
                    ? 'bg-black text-white shadow-md' 
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {t.features.forPassengers}
              </button>
              <button
                onClick={() => setActiveTab('driver')}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 cursor-pointer ${
                  activeTab === 'driver' 
                    ? 'bg-black text-white shadow-md' 
                    : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {t.features.forDrivers}
              </button>
            </div>
          </div>
        </div>

        {/* Feature Grid content container */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {activeItems.map((item, i) => (
            <motion.div
              layoutId={`${activeTab}-${item.title}`}
              key={`${activeTab}-${i}`}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className={`flex flex-col p-6 rounded-2xl border border-zinc-200/80 bg-zinc-50/50 hover:bg-white hover:border-black hover:shadow-xl hover:shadow-zinc-100 transition duration-300 group ${isRtl ? 'text-right' : 'text-left'}`}
            >
              <div className={`p-3 bg-white border border-zinc-100 inline-flex rounded-xl group-hover:bg-black group-hover:text-white group-hover:border-black transition duration-300 ${isRtl ? 'self-end' : 'self-start'}`}>
                {activeIcons[i] || <HelpCircle className="h-6 w-6 text-zinc-400" />}
              </div>
              <h3 className="font-display font-bold text-lg text-zinc-950 mt-5 group-hover:text-black transition">
                {item.title}
              </h3>
              <p className="text-sm text-zinc-600 leading-relaxed font-light mt-2">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
