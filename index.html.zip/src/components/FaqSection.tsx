import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle, User, Car, Settings } from 'lucide-react';
import { TranslationDict, Language } from '../translations';

interface FaqSectionProps {
  t: TranslationDict;
  lang: Language;
}

export default function FaqSection({ t, lang }: FaqSectionProps) {
  const [activeCategory, setActiveCategory] = useState<'all' | 'driver' | 'passenger' | 'general'>('all');
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const isRtl = t.dir === 'rtl';

  const filteredFaqs = activeCategory === 'all' 
    ? t.faq.items 
    : t.faq.items.filter(faq => faq.category === activeCategory);

  const handleToggle = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-white text-slate-950 border-t border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Header Title */}
        <div className={`max-w-3xl mx-auto mb-14 ${isRtl ? 'text-right' : 'text-center'}`}>
          <div className="flex justify-center mb-4">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
              {t.faq.badge}
            </span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight mt-4 text-slate-950">
            {t.faq.title}
          </h2>
          <p className="text-slate-600 mt-3 font-light leading-relaxed">
            {t.faq.subtitle}
          </p>

          {/* Categories Toggle Row */}
          <div className={`mt-8 flex flex-wrap justify-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
            {[
              { id: 'all', name: t.faq.catAll, icon: <HelpCircle className="h-3.5 w-3.5" /> },
              { id: 'general', name: t.faq.catGeneral, icon: <Settings className="h-3.5 w-3.5" /> },
              { id: 'driver', name: t.faq.catDriver, icon: <Car className="h-3.5 w-3.5" /> },
              { id: 'passenger', name: t.faq.catPassenger, icon: <User className="h-3.5 w-3.5" /> }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id as any);
                  setExpandedIndex(null);
                }}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold tracking-wider transition duration-200 border cursor-pointer ${isRtl ? 'flex-row-reverse' : ''} ${
                  activeCategory === cat.id
                    ? 'bg-slate-950 text-white border-slate-950 shadow-md'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-white'
                }`}
              >
                {cat.icon}
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* FAQs Accordion layout */}
        <div className="space-y-4">
          {filteredFaqs.map((faq, index) => {
            const isExpanded = expandedIndex === index;
            return (
              <div 
                key={index}
                className="border border-slate-200/90 rounded-2xl bg-slate-50/50 hover:bg-white overflow-hidden transition-all duration-300"
              >
                {/* Header Toggle Clickable */}
                <button
                  onClick={() => handleToggle(index)}
                  className={`w-full px-6 py-5 flex items-center justify-between gap-4 font-display font-medium text-slate-950 cursor-pointer ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}
                >
                  <span className="text-slate-900 font-semibold tracking-tight text-base sm:text-lg">
                    {faq.question}
                  </span>
                  <div className={`p-1 bg-slate-100 hover:bg-slate-200/80 rounded-lg text-slate-500 transition-transform duration-300 ${isRtl ? 'order-first' : ''} ${
                    isExpanded ? 'rotate-180 bg-black text-white' : ''
                  }`}>
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </button>

                {/* Expanded Answer Content */}
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <div className={`px-6 pb-6 pt-1 text-sm text-slate-600 leading-relaxed font-light border-t border-slate-150/45 ${isRtl ? 'text-right' : 'text-left'}`}>
                        {faq.answer}
                        
                        <div className={`mt-4 flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                          <span className="text-[9px] font-mono uppercase font-bold text-slate-400 bg-slate-100 border border-slate-200/60 px-2 py-0.5 rounded">
                            {lang === 'ar' ? 'تصنيف:' : lang === 'fr' ? 'Catégorie:' : 'Category:'} {faq.category === 'passenger' ? t.register.rolePassenger : faq.category === 'driver' ? t.register.roleDriver : t.faq.catGeneral}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
