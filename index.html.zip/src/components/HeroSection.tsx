import { motion } from 'motion/react';
import { Smartphone, Download, Shield, MapPin, Star, ArrowRight } from 'lucide-react';
// @ts-ignore
import appMockup from '../assets/images/app_mockup_1779331391842.png';
import { TranslationDict, Language } from '../translations';

interface HeroSectionProps {
  onScrollToRegister: (tab: 'driver' | 'passenger') => void;
  t: TranslationDict;
  lang: Language;
}

export default function HeroSection({ onScrollToRegister, t, lang }: HeroSectionProps) {
  const isRtl = t.dir === 'rtl';

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-zinc-200 via-zinc-150 to-zinc-100 text-zinc-900 py-16 lg:py-28 px-4 sm:px-6 lg:px-8 border-b border-zinc-200/80">
      {/* Decorative subtle ambient gray blurred circles */}
      <div className="absolute top-1/4 -left-36 w-96 h-96 bg-zinc-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-zinc-300/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        
        {/* Left column: Text Content */}
        <div className={`lg:col-span-7 flex flex-col space-y-8 ${isRtl ? 'text-right' : 'text-left'}`}>
          
          {/* Badge */}
          <motion.div 
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className={`inline-flex self-start items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-zinc-300 shadow-sm ${isRtl ? 'flex-row-reverse self-start' : 'self-start'}`}
          >
            <span className="flex h-2 w-2 rounded-full bg-zinc-900 animate-pulse" />
            <span className="text-xs font-mono tracking-wide text-zinc-800 uppercase font-bold">{t.hero.badge}</span>
          </motion.div>

          {/* Main Headline */}
          <div className="space-y-4">
            <motion.h1 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-zinc-950"
            >
              {t.hero.title1} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-zinc-950 via-zinc-800 to-zinc-650 font-display font-extrabold">
                {t.hero.accentTitle}
              </span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-zinc-700 max-w-xl font-sans font-normal leading-relaxed animate-fade-in"
            >
              {t.hero.subtitle}
            </motion.p>
          </div>

          {/* Value Highlights */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="grid grid-cols-2 sm:grid-cols-3 gap-4"
          >
            <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <div className="p-2 bg-white/90 border border-zinc-300 rounded-lg text-black shadow-sm">
                <MapPin className="h-5 w-5 text-zinc-900" />
              </div>
              <div className={isRtl ? 'text-right' : 'text-left'}>
                <p className="text-sm font-bold text-zinc-800">{t.hero.gps}</p>
                <p className="text-xs text-zinc-600 font-sans">{t.hero.gpsSub}</p>
              </div>
            </div>

            <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <div className="p-2 bg-white/90 border border-zinc-300 rounded-lg text-black shadow-sm">
                <Shield className="h-5 w-5 text-zinc-900" />
              </div>
              <div className={isRtl ? 'text-right' : 'text-left'}>
                <p className="text-sm font-bold text-zinc-800">{t.hero.safety}</p>
                <p className="text-xs text-zinc-650 font-sans">{t.hero.safetySub}</p>
              </div>
            </div>

            <div className={`col-span-2 sm:col-span-1 flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <div className="p-2 bg-white/90 border border-zinc-300 rounded-lg text-black shadow-sm">
                <Star className="h-5 w-5 text-zinc-900" />
              </div>
              <div className={isRtl ? 'text-right' : 'text-left'}>
                <p className="text-sm font-bold text-zinc-800">{t.hero.rates}</p>
                <p className="text-xs text-zinc-650 font-sans">{t.hero.ratesSub}</p>
              </div>
            </div>
          </motion.div>

          {/* Action buttons list */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className={`flex flex-col sm:flex-row gap-4 pt-4 ${isRtl ? 'sm:flex-row-reverse justify-end' : ''}`}
          >
            <button
              onClick={() => onScrollToRegister('passenger')}
              className="group flex items-center justify-center gap-2 bg-black hover:bg-zinc-900 text-white font-semibold px-6 py-4 rounded-xl shadow-md hover:scale-[1.02] transition-all duration-300 cursor-pointer"
            >
              {t.hero.passengerBtn}
              <ArrowRight className={`h-4 w-4 transition-transform ${isRtl ? 'rotate-180 group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
            </button>
            
            <button
              onClick={() => onScrollToRegister('driver')}
              className="group flex items-center justify-center gap-2 bg-white hover:bg-zinc-50 text-zinc-800 font-semibold px-6 py-4 rounded-xl border border-zinc-300 shadow-sm transition-all duration-300 hover:scale-[1.02] cursor-pointer"
            >
              {t.hero.driverBtn}
              <ArrowRight className={`h-4 w-4 text-zinc-550 transition-transform ${isRtl ? 'rotate-180 group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
            </button>
          </motion.div>

          {/* Playstore Badges CTA */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className={`flex flex-col space-y-3 pt-6 border-t border-zinc-300 max-w-lg ${isRtl ? 'items-end' : 'items-start'}`}
          >
            <p className="text-xs font-mono uppercase tracking-widest text-zinc-650">{t.hero.apkBadge}</p>
            <div className={`flex flex-wrap gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <a 
                href="https://play.google.com/store" 
                target="_blank" 
                rel="noreferrer"
                id="play-store-hero-download"
                className={`flex items-center gap-3 px-5 py-2.5 bg-black hover:bg-zinc-900 border border-zinc-850 text-white rounded-xl transition duration-300 cursor-pointer shadow-md ${isRtl ? 'flex-row-reverse' : ''}`}
              >
                <Download className="h-6 w-6 text-white" />
                <div className={isRtl ? 'text-right' : 'text-left'}>
                  <p className="text-[10px] font-mono leading-none text-zinc-400 uppercase">{t.hero.storeLabel}</p>
                  <p className="text-sm font-semibold tracking-tight leading-normal mt-0.5">{t.hero.storeSub}</p>
                </div>
              </a>
              <div className={`flex items-center gap-1.5 text-xs text-zinc-700 font-medium ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Smartphone className="h-4 w-4 text-zinc-600" />
                <span>{t.hero.compatibility}</span>
              </div>
            </div>
          </motion.div>

        </div>

        {/* Right column: Beautiful Phone Mockup Graphic Rendering with CSS Monochrome filter */}
        <div className="lg:col-span-5 relative flex justify-center">
          
          {/* Visual highlight aura under the mockup */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] bg-zinc-300/20 rounded-full blur-3xl pointer-events-none" />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotateY: 15 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ type: "spring", stiffness: 60, delay: 0.3, duration: 0.8 }}
            className="relative max-w-[320px] sm:max-w-[360px] cursor-pointer"
          >
            {/* Phone Wrapper frame for graphic mockup */}
            <div className="relative p-3.5 bg-white border-4 border-zinc-300 rounded-[44px] shadow-xl overflow-hidden shadow-zinc-305/50">
              <div className="absolute top-5 left-1/2 -translate-x-1/2 w-32 h-5 bg-zinc-900 rounded-full z-20 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-zinc-950 absolute right-4" />
                <div className="w-12 h-1 bg-zinc-950 rounded-full absolute left-6" />
              </div>
              
              <img
                src={appMockup}
                alt="Atlas Ride Mobile App Mockup Screen showing live taxi routes"
                referrerPolicy="no-referrer"
                className="w-full h-auto rounded-[32px] block relative z-10 brightness-[1.03] select-none scale-[1.01] grayscale contrast-[1.10] border border-zinc-200"
              />
            </div>

            {/* Float badge widget 1 */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className={`absolute -left-6 bottom-1/4 bg-white border border-zinc-250 p-3.5 rounded-2xl shadow-lg z-20 flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <div className="flex items-center justify-center h-8 w-8 rounded-full bg-zinc-100 text-zinc-900 border border-zinc-200">
                <svg className="w-5 h-5 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className={isRtl ? 'text-right' : 'text-left'}>
                <p className="text-xs font-bold text-zinc-900">{t.hero.etaBadge}</p>
                <p className="text-[10px] text-zinc-500 font-medium">{t.hero.etaSub}</p>
              </div>
            </motion.div>

            {/* Float badge widget 2 */}
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 4.5, ease: "easeInOut", delay: 0.5 }}
              className={`absolute -right-8 top-1/4 bg-white border border-zinc-250 p-3.5 rounded-2xl shadow-lg z-20 flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <div className={isRtl ? 'text-right font-sans' : 'text-right font-sans'}>
                <p className="text-xs font-bold text-zinc-900">{t.hero.safetyBadge}</p>
                <p className="text-[10px] text-zinc-455 font-medium">{t.hero.safetySub2}</p>
              </div>
              <div className="flex items-center justify-center h-8 w-8 rounded-full bg-zinc-100 text-black border border-zinc-200">
                <Shield className="h-4.5 w-4.5 text-zinc-800" />
              </div>
            </motion.div>
          </motion.div>

        </div>

      </div>
    </section>
  );
}
