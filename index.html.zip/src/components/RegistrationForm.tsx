import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Mail, Phone, MapPin, Car, ShieldCheck, 
  Smartphone, Award, Check, Sparkles, AlertCircle, RefreshCw, Send, ArrowRight
} from 'lucide-react';
import { RegisteredDriver, RegisteredPassenger } from '../types';
import { TranslationDict, Language } from '../translations';

interface RegistrationFormProps {
  onRegisterDriver: (driver: RegisteredDriver) => void;
  onRegisterPassenger: (passenger: RegisteredPassenger) => void;
  initialTab?: 'driver' | 'passenger';
  t: TranslationDict;
  lang: Language;
}

export default function RegistrationForm({ 
  onRegisterDriver, 
  onRegisterPassenger,
  initialTab = 'passenger',
  t,
  lang
}: RegistrationFormProps) {
  const [formType, setFormType] = useState<'passenger' | 'driver'>(initialTab);
  const [step, setStep] = useState<number>(1); // Step 1: Contact, Step 2: Details
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [justSubmitted, setJustSubmitted] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const isRtl = t.dir === 'rtl';

  // Form States - Passenger
  const [passName, setPassName] = useState('');
  const [passEmail, setPassEmail] = useState('');
  const [passPhone, setPassPhone] = useState('');
  const [passPayment, setPassPayment] = useState<'card' | 'cash' | 'mobile_wallet'>('card');
  const [passReferral, setPassReferral] = useState('');

  // Form States - Driver
  const [drvName, setDrvName] = useState('');
  const [drvEmail, setDrvEmail] = useState('');
  const [drvPhone, setDrvPhone] = useState('');
  const [drvCity, setDrvCity] = useState('');
  const [drvType, setDrvType] = useState<'economy' | 'premium' | 'xl' | 'delivery'>('economy');
  const [drvModel, setDrvModel] = useState('');
  const [drvPlate, setDrvPlate] = useState('');
  const [drvLicense, setDrvLicense] = useState('');

  // Validation function
  const validateStep1 = () => {
    setErrorMessage('');
    const nameVal = formType === 'passenger' ? passName : drvName;
    const emailVal = formType === 'passenger' ? passEmail : drvEmail;
    const phoneVal = formType === 'passenger' ? passPhone : drvPhone;

    if (!nameVal.trim()) {
      setErrorMessage(t.register.errorName);
      return false;
    }
    if (!emailVal.trim() || !emailVal.includes('@')) {
      setErrorMessage(t.register.errorEmail);
      return false;
    }
    if (!phoneVal.trim() || phoneVal.length < 5) {
      setErrorMessage(t.register.errorPhone);
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleBackStep = () => {
    setErrorMessage('');
    setStep(1);
  };

  const handlePassengerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!validateStep1()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const newPassenger: RegisteredPassenger = {
        id: 'p-' + Math.random().toString(36).substr(2, 9),
        name: passName,
        email: passEmail,
        phone: passPhone,
        preferredPayment: passPayment,
        referralCode: passReferral || undefined,
        registeredAt: new Date().toLocaleString(lang === 'ar' ? 'ar-EG' : lang === 'fr' ? 'fr-FR' : 'en-US'),
        status: 'active'
      };

      // Push update to root state triggers
      onRegisterPassenger(newPassenger);

      setIsSubmitting(false);
      setJustSubmitted(true);
      setStep(3);
    }, 1200);
  };

  const handleDriverSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!validateStep1()) return;

    if (!drvCity.trim()) {
      setErrorMessage(t.register.errorCity);
      return;
    }
    if (!drvModel.trim()) {
      setErrorMessage(t.register.errorModel);
      return;
    }
    if (!drvPlate.trim()) {
      setErrorMessage(t.register.errorPlate);
      return;
    }
    if (!drvLicense.trim()) {
      setErrorMessage(t.register.errorLicense);
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const newDriver: RegisteredDriver = {
        id: 'd-' + Math.random().toString(36).substr(2, 9),
        name: drvName,
        email: drvEmail,
        phone: drvPhone,
        city: drvCity,
        vehicleType: drvType,
        vehicleModel: drvModel,
        licensePlate: drvPlate,
        licenseNumber: drvLicense,
        registeredAt: new Date().toLocaleString(lang === 'ar' ? 'ar-EG' : lang === 'fr' ? 'fr-FR' : 'en-US'),
        status: 'pending_review'
      };

      onRegisterDriver(newDriver);

      setIsSubmitting(false);
      setJustSubmitted(true);
      setStep(3);
    }, 1400);
  };

  const resetForm = () => {
    setStep(1);
    setJustSubmitted(false);
    setErrorMessage('');
    // Clear State
    if (formType === 'passenger') {
      setPassName('');
      setPassEmail('');
      setPassPhone('');
      setPassReferral('');
    } else {
      setDrvName('');
      setDrvEmail('');
      setDrvPhone('');
      setDrvCity('');
      setDrvModel('');
      setDrvPlate('');
      setDrvLicense('');
    }
  };

  return (
    <section id="register-section" className="py-20 bg-zinc-50 text-slate-800 border-t border-b border-zinc-200/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Main Card Holder */}
        <div className="bg-white rounded-3xl border border-zinc-200 shadow-2xl shadow-zinc-200/50 overflow-hidden">
          
          {/* Header background accents in deep black/gray */}
          <div className="bg-black text-white px-8 py-10 relative overflow-hidden border-b border-zinc-850">
            <div className="absolute top-0 right-0 w-64 h-64 bg-zinc-700/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-zinc-650/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="relative z-10 text-center max-w-xl mx-auto">
              <span className="text-xs font-mono tracking-widest text-zinc-400 font-semibold uppercase">{t.register.badge}</span>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
                {t.register.title}
              </h2>
              <p className="text-zinc-450 text-sm font-sans font-light mt-2 leading-relaxed">
                {t.register.subtitle}
              </p>
            </div>

            {/* Switch Tab buttons (monochrome) */}
            {!justSubmitted && (
              <div className="mt-8 flex justify-center relative z-10">
                <div className={`inline-flex p-1 bg-zinc-900 border border-zinc-800 rounded-xl ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                  <button
                    onClick={() => {
                      if (!isSubmitting) {
                        setFormType('passenger');
                        setStep(1);
                        setErrorMessage('');
                      }
                    }}
                    className={`px-5 py-2 rounded-lg text-xs font-semibold tracking-wide transition duration-200 flex items-center gap-1.5 cursor-pointer ${
                      formType === 'passenger' 
                        ? 'bg-white text-black shadow-md' 
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    <User className="h-3.5 w-3.5" />
                    {t.register.tabPassenger}
                  </button>
                  <button
                    onClick={() => {
                      if (!isSubmitting) {
                        setFormType('driver');
                        setStep(1);
                        setErrorMessage('');
                      }
                    }}
                    className={`px-5 py-2 rounded-lg text-xs font-semibold tracking-wide transition duration-200 flex items-center gap-1.5 cursor-pointer ${
                      formType === 'driver' 
                        ? 'bg-white text-black shadow-md' 
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    <Car className="h-3.5 w-3.5" />
                    {t.register.tabDriver}
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="px-6 py-8 sm:p-10 bg-white">
            {/* Step Indicators */}
            {!justSubmitted && (
              <div className={`flex justify-center items-center gap-3 mb-8 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                  <span className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-mono font-bold transition ${
                    step >= 1 ? 'bg-black text-white' : 'bg-zinc-100 text-zinc-400'
                  }`}>1</span>
                  <span className="text-xs font-semibold text-zinc-800">{t.register.step1}</span>
                </div>
                <div className="h-[2px] w-12 bg-zinc-200" />
                <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                  <span className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-mono font-bold transition ${
                    step >= 2 ? 'bg-black text-white' : 'bg-zinc-100 text-zinc-400'
                  }`}>2</span>
                  <span className="text-xs font-semibold text-zinc-500">
                    {formType === 'passenger' ? t.register.step2Passenger : t.register.step2Driver}
                  </span>
                </div>
              </div>
            )}

            {/* Error notifications */}
            {errorMessage && (
              <motion.div 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className={`mb-6 p-4 bg-zinc-50 border border-zinc-250 text-zinc-800 text-sm rounded-xl flex items-center gap-2.5 ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}
              >
                <AlertCircle className="h-4 w-4 text-black flex-shrink-0" />
                <span>{errorMessage}</span>
              </motion.div>
            )}

            {/* Forms rendering */}
            <AnimatePresence mode="wait">
              
              {/* STEP 1: Core details for both */}
              {step === 1 && !justSubmitted && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelName}</label>
                      <div className="relative">
                        <User className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                        <input
                          id={`${formType}-name`}
                          type="text"
                          placeholder={t.register.placeholderName}
                          value={formType === 'passenger' ? passName : drvName}
                          onChange={(e) => formType === 'passenger' ? setPassName(e.target.value) : setDrvName(e.target.value)}
                          className={`w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250`}
                        />
                      </div>
                    </div>

                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelEmail}</label>
                      <div className="relative">
                        <Mail className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                        <input
                          id={`${formType}-email`}
                          type="email"
                          placeholder={t.register.placeholderEmail}
                          value={formType === 'passenger' ? passEmail : drvEmail}
                          onChange={(e) => formType === 'passenger' ? setPassEmail(e.target.value) : setDrvEmail(e.target.value)}
                          className={`w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-255`}
                        />
                      </div>
                    </div>
                  </div>

                  <div className={isRtl ? 'text-right' : 'text-left'}>
                    <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelPhone}</label>
                    <div className="relative">
                      <Phone className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                      <input
                        id={`${formType}-phone`}
                        type="tel"
                        placeholder={t.register.placeholderPhone}
                        value={formType === 'passenger' ? passPhone : drvPhone}
                        onChange={(e) => formType === 'passenger' ? setPassPhone(e.target.value) : setDrvPhone(e.target.value)}
                        className={`w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-255`}
                      />
                    </div>
                    <p className="text-[10px] text-zinc-450 mt-1">{t.register.phoneHint}</p>
                  </div>

                  <div className={`pt-4 flex ${isRtl ? 'justify-start' : 'justify-end'}`}>
                    <button
                      type="button"
                      onClick={handleNextStep}
                      className={`flex items-center gap-2 bg-black hover:bg-zinc-900 text-white font-semibold px-6 py-3 rounded-xl transition duration-200 shadow-md group cursor-pointer ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                      {t.register.btnNext}
                      <ArrowRight className={`h-4 w-4 transition group-hover:translate-x-1 text-zinc-300 ${isRtl ? 'rotate-180 group-hover:-translate-x-1' : ''}`} />
                    </button>
                  </div>
                </motion.div>
              )}

              {/* STEP 2A: Driver Vehicle details */}
              {step === 2 && formType === 'driver' && !justSubmitted && (
                <motion.form
                  key="driver-step2"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  onSubmit={handleDriverSubmit}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelCity}</label>
                      <div className="relative">
                        <MapPin className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                        <input
                          id="driver-city"
                          type="text"
                          placeholder={t.register.placeholderCity}
                          value={drvCity}
                          onChange={(e) => setDrvCity(e.target.value)}
                          className={`w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250`}
                        />
                      </div>
                    </div>

                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelLicense}</label>
                      <div className="relative">
                        <Award className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                        <input
                          id="driver-license"
                          type="text"
                          placeholder={t.register.placeholderLicense}
                          value={drvLicense}
                          onChange={(e) => setDrvLicense(e.target.value)}
                          className={`font-mono w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250`}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div className={`sm:col-span-2 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelModel}</label>
                      <div className="relative">
                        <Car className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400`} />
                        <input
                          id="driver-model"
                          type="text"
                          placeholder={t.register.placeholderModel}
                          value={drvModel}
                          onChange={(e) => setDrvModel(e.target.value)}
                          className={`w-full ${isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250`}
                        />
                      </div>
                    </div>

                    <div className={isRtl ? 'text-right' : 'text-left'}>
                      <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelPlate}</label>
                      <input
                        id="driver-plate"
                        type="text"
                        placeholder={t.register.placeholderPlate}
                        value={drvPlate}
                        onChange={(e) => setDrvPlate(e.target.value)}
                        className={`font-mono w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250 uppercase ${isRtl ? 'text-right' : 'text-left'}`}
                      />
                    </div>
                  </div>

                  <div className={isRtl ? 'text-right' : 'text-left'}>
                    <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-3">{t.register.labelClass}</label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {(['economy', 'premium', 'xl', 'delivery'] as const).map((tier) => (
                        <label 
                          key={tier}
                          className={`relative flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition text-center select-none ${
                            drvType === tier 
                              ? 'border-black bg-zinc-50 text-black font-semibold' 
                              : 'border-zinc-200 bg-zinc-50/50 hover:bg-white hover:border-zinc-300 text-zinc-600'
                          }`}
                        >
                          <input
                            type="radio"
                            name="driverType"
                            checked={drvType === tier}
                            onChange={() => setDrvType(tier)}
                            className="sr-only"
                          />
                          <span className="text-sm uppercase tracking-wide block font-bold font-sans">{tier}</span>
                          <span className="text-[10px] text-zinc-400 leading-none mt-1">
                            {tier === 'economy' && (lang === 'ar' ? 'اقتصادي موفر' : lang === 'fr' ? 'Fares abordables' : 'Affordable fares')}
                            {tier === 'premium' && (lang === 'ar' ? 'فخامة ورفاهية' : lang === 'fr' ? 'Luxe Premium' : 'Premium luxury')}
                            {tier === 'xl' && (lang === 'ar' ? 'عائلي رحب' : lang === 'fr' ? 'Spacieux Famille' : 'Family spacious')}
                            {tier === 'delivery' && (lang === 'ar' ? 'توصيل شحنات' : lang === 'fr' ? 'Colis rapide' : 'High-speed parcel')}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className={`pt-6 border-t border-zinc-100 flex items-center justify-between ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <button
                      type="button"
                      onClick={handleBackStep}
                      className="px-5 py-3 border border-zinc-200 text-zinc-650 font-semibold text-sm rounded-xl hover:bg-zinc-50 transition cursor-pointer"
                    >
                      {t.register.btnBack}
                    </button>
                    
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex items-center gap-2 bg-black hover:bg-zinc-900 disabled:bg-zinc-200 text-white font-semibold px-6 py-3 rounded-xl transition duration-200 shadow-md cursor-pointer"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          {t.register.btnSubmitDriverLoading}
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          {t.register.btnSubmitDriver}
                        </>
                      )}
                    </button>
                  </div>
                </motion.form>
              )}

              {/* STEP 2B: Passenger Details */}
              {step === 2 && formType === 'passenger' && !justSubmitted && (
                <motion.form
                  key="passenger-step2"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  onSubmit={handlePassengerSubmit}
                  className="space-y-6"
                >
                  <div className={isRtl ? 'text-right' : 'text-left'}>
                    <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-3">{t.register.paymentLabel}</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {([
                        { key: 'card', name: t.register.paymentMethods.card, desc: t.register.paymentDescCard },
                        { key: 'cash', name: t.register.paymentMethods.cash, desc: t.register.paymentDescCash },
                        { key: 'mobile_wallet', name: t.register.paymentMethods.wallet, desc: t.register.paymentDescWallet }
                      ] as const).map((method) => (
                        <label 
                          key={method.key}
                          className={`flex flex-col p-4 rounded-xl border-2 cursor-pointer transition select-none ${isRtl ? 'text-right' : 'text-left'} ${
                            passPayment === method.key 
                              ? 'border-black bg-zinc-50' 
                              : 'border-zinc-205 bg-zinc-50/50 hover:bg-white hover:border-zinc-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name="paymentMethod"
                            checked={passPayment === method.key}
                            onChange={() => setPassPayment(method.key)}
                            className="sr-only"
                          />
                          <span className={`text-sm font-bold block ${passPayment === method.key ? 'text-black font-extrabold' : 'text-zinc-700'}`}>{method.name}</span>
                          <span className="text-[11px] text-zinc-450 mt-1">{method.desc}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className={isRtl ? 'text-right' : 'text-left'}>
                    <label className="block text-xs font-bold uppercase tracking-wide text-zinc-700 mb-2">{t.register.labelReferral}</label>
                    <input
                      id="passenger-referral"
                      type="text"
                      placeholder="e.g. WELCOME50"
                      value={passReferral}
                      onChange={(e) => setPassReferral(e.target.value)}
                      className={`font-mono w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-900 placeholder-zinc-450 text-sm focus:bg-white focus:border-black focus:ring-2 focus:ring-black/5 outline-none transition duration-250 uppercase ${isRtl ? 'text-right' : 'text-left'}`}
                    />
                    <p className="text-[10px] text-zinc-450 mt-1">{t.register.referralHint}</p>
                  </div>

                  <div className={`pt-6 border-t border-zinc-100 flex items-center justify-between ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <button
                      type="button"
                      onClick={handleBackStep}
                      className="px-5 py-3 border border-zinc-200 text-zinc-650 font-semibold text-sm rounded-xl hover:bg-zinc-50 transition cursor-pointer"
                    >
                      {t.register.btnBack}
                    </button>
                    
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex items-center gap-2 bg-black hover:bg-zinc-900 disabled:bg-zinc-200 text-white font-semibold px-6 py-3 rounded-xl transition duration-200 shadow-md cursor-pointer"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          {t.register.btnSubmitPassengerLoading}
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          {t.register.btnSubmitPassenger}
                        </>
                      )}
                    </button>
                  </div>
                </motion.form>
              )}

              {/* STEP 3: Beautiful celebration panel & play store prompt (monochrome style) */}
              {step === 3 && justSubmitted && (
                <motion.div
                  key="success-celebration"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-8 space-y-6"
                >
                  <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-zinc-100 text-black border border-zinc-200 relative">
                    <Check className="h-8 w-8 stroke-[3]" />
                    <Sparkles className="absolute -top-1 -right-1 h-5 w-5 text-zinc-500 animate-bounce" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-display text-2xl font-extrabold text-black">{t.register.successTitle}</h3>
                    <p className="text-sm text-zinc-500 max-w-lg mx-auto leading-relaxed">
                      {t.register.successDesc}
                    </p>
                  </div>

                  {/* Registered Credentials summary mockup */}
                  <div className={`max-w-md mx-auto p-5 rounded-2xl border border-dashed border-zinc-300 bg-zinc-50 text-zinc-600 space-y-1 font-mono text-xs ${isRtl ? 'text-right' : 'text-left'}`}>
                    <p className={`font-sans font-bold text-zinc-800 text-sm mb-2 border-b border-zinc-200 pb-1 flex ${isRtl ? 'flex-row-reverse justify-between' : 'justify-between'}`}>
                      <span>📋 {t.register.successRecord}</span>
                      <span className="text-[10px] text-zinc-400 font-normal">{t.register.successLocal}</span>
                    </p>
                    <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <span className="text-zinc-405 font-normal">{t.register.roleLabel}:</span> 
                      <span>{formType === 'passenger' ? t.register.rolePassenger : t.register.roleDriver}</span>
                    </p>
                    <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <span className="text-zinc-405">{t.register.summaryName}:</span> 
                      <span>{formType === 'passenger' ? passName : drvName}</span>
                    </p>
                    <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse text-wrap text-xs' : ''}`}>
                      <span className="text-zinc-405">{t.register.summaryContact}:</span> 
                      <span>{formType === 'passenger' ? passPhone : drvPhone} | {formType === 'passenger' ? passEmail : drvEmail}</span>
                    </p>
                    {formType === 'driver' ? (
                      <>
                        <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                          <span className="text-zinc-405">{t.register.summaryClass}:</span> 
                          <span>{drvType.toUpperCase()}</span>
                        </p>
                        <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                          <span className="text-zinc-405">{t.register.summaryVehicle}:</span> 
                          <span>{drvModel} ({drvPlate})</span>
                        </p>
                      </>
                    ) : (
                      <>
                        <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                          <span className="text-zinc-405">{t.register.summarySettle}:</span> 
                          <span>{passPayment.replace('_', ' ').toUpperCase()}</span>
                        </p>
                        {passReferral && (
                          <p className={`flex gap-1.5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                            <span className="text-zinc-405">{t.register.summaryReferral}:</span> 
                            <span>{passReferral}</span>
                          </p>
                        )}
                      </>
                    )}
                  </div>

                  {/* Android Install redirection */}
                  <div className="pt-4 space-y-4 max-w-md mx-auto border-t border-zinc-150">
                    <div className="flex flex-col space-y-1.5">
                      <p className="text-sm font-bold text-zinc-800 flex items-center justify-center gap-1.5">
                        <Smartphone className="h-4.5 w-4.5 text-zinc-500 animate-pulse" />
                        {t.register.nextStepLabel}
                      </p>
                      <p className="text-xs text-zinc-500">
                        {t.register.nextStepDesc}
                      </p>
                    </div>

                    <div className={`flex flex-col sm:flex-row gap-3 justify-center items-center ${isRtl ? 'sm:flex-row-reverse' : ''}`}>
                      <a 
                        href="https://play.google.com/store" 
                        target="_blank" 
                        rel="noreferrer"
                        id="play-store-success-download"
                        className={`flex items-center justify-center gap-2.5 px-5 py-2.5 bg-black hover:bg-zinc-900 border border-zinc-800 text-white rounded-xl transition duration-200 shadow-md text-left cursor-pointer ${isRtl ? 'flex-row-reverse' : ''}`}
                      >
                        <Smartphone className="h-5 w-5 text-white" />
                        <div className={isRtl ? 'text-right' : 'text-left'}>
                          <p className="text-[9px] font-mono leading-none text-zinc-400">GET IT ON</p>
                          <p className="text-xs font-semibold leading-normal mt-0.5">Google Play</p>
                        </div>
                      </a>

                      <button
                        onClick={resetForm}
                        className="px-5 py-2.5 text-xs text-zinc-650 hover:bg-zinc-100 rounded-xl transition font-semibold cursor-pointer"
                      >
                        {t.register.btnRegAnother}
                      </button>
                    </div>
                  </div>

                </motion.div>
              )}

            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
