import React from 'react';

interface LogoProps {
  className?: string;
  isDark?: boolean;
  isRtl?: boolean;
}

export default function Logo({ className = '', isDark = false, isRtl = false }: LogoProps) {
  return (
    <div className={`flex items-center gap-3 ${className} ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* The AR Monogram matching the uploaded image exactly */}
      <div className={`flex flex-col items-center justify-center rounded-xl transition-all duration-300 h-11 w-11 flex-shrink-0 border shadow-sm ${
        isDark 
          ? 'bg-zinc-800 border-zinc-700 text-white' 
          : 'bg-zinc-200 border-zinc-300 text-zinc-950'
      }`}>
        <span className="font-serif font-black text-xl tracking-tighter leading-none select-none">AR</span>
      </div>
      <div className={`flex flex-col ${isRtl ? 'text-right' : 'text-left'}`}>
        <span className={`font-sans font-black text-[16px] sm:text-lg tracking-tight leading-none uppercase ${
          isDark ? 'text-white' : 'text-zinc-950'
        }`}>
          Atlas Ride
        </span>
        <span className={`text-[9px] font-mono tracking-wider font-extrabold leading-none mt-1 ${
          isDark ? 'text-zinc-400' : 'text-zinc-500'
        }`}>
          {isRtl ? 'بوابة أندرويد' : 'Android Hub'}
        </span>
      </div>
    </div>
  );
}
