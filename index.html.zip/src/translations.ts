export type Language = 'en' | 'fr' | 'ar';

export interface TranslationDict {
  dir: 'ltr' | 'rtl';
  brand: string;
  tagline: string;
  header: {
    features: string;
    register: string;
    faq: string;
    getApp: string;
    androidHub: string;
  };
  hero: {
    badge: string;
    title1: string;
    accentTitle: string;
    subtitle: string;
    gps: string;
    gpsSub: string;
    safety: string;
    safetySub: string;
    rates: string;
    ratesSub: string;
    passengerBtn: string;
    driverBtn: string;
    apkBadge: string;
    storeLabel: string;
    storeSub: string;
    compatibility: string;
    etaBadge: string;
    etaSub: string;
    safetyBadge: string;
    safetySub2: string;
  };
  features: {
    badge: string;
    title: string;
    subtitle: string;
    forPassengers: string;
    forDrivers: string;
    passengerItems: {
      title: string;
      desc: string;
    }[];
    driverItems: {
      title: string;
      desc: string;
    }[];
  };
  register: {
    badge: string;
    title: string;
    subtitle: string;
    tabPassenger: string;
    tabDriver: string;
    step1: string;
    step2Passenger: string;
    step2Driver: string;
    errorName: string;
    errorEmail: string;
    errorPhone: string;
    errorCity: string;
    errorModel: string;
    errorPlate: string;
    errorLicense: string;
    labelName: string;
    placeholderName: string;
    labelEmail: string;
    placeholderEmail: string;
    labelPhone: string;
    placeholderPhone: string;
    phoneHint: string;
    labelCity: string;
    placeholderCity: string;
    labelLicense: string;
    placeholderLicense: string;
    labelModel: string;
    placeholderModel: string;
    labelPlate: string;
    placeholderPlate: string;
    labelClass: string;
    btnNext: string;
    paymentLabel: string;
    paymentDescCard: string;
    paymentDescCash: string;
    paymentDescWallet: string;
    paymentMethods: {
      card: string;
      cash: string;
      wallet: string;
    };
    labelReferral: string;
    referralHint: string;
    btnBack: string;
    btnSubmitDriver: string;
    btnSubmitDriverLoading: string;
    btnSubmitPassenger: string;
    btnSubmitPassengerLoading: string;
    successTitle: string;
    successDesc: string;
    successRecord: string;
    successLocal: string;
    roleLabel: string;
    rolePassenger: string;
    roleDriver: string;
    summaryName: string;
    summaryContact: string;
    summaryClass: string;
    summaryVehicle: string;
    summarySettle: string;
    summaryReferral: string;
    nextStepLabel: string;
    nextStepDesc: string;
    btnRegAnother: string;
  };
  faq: {
    badge: string;
    title: string;
    subtitle: string;
    catAll: string;
    catGeneral: string;
    catDriver: string;
    catPassenger: string;
    items: {
      question: string;
      answer: string;
      category: string;
    }[];
  };
  admin: {
    title: string;
    desc: string;
    btnReset: string;
    btnInspectorClose: string;
    btnInspectorOpen: string;
    sandboxed: string;
    tabDrivers: string;
    tabPassengers: string;
    noDrivers: string;
    noPassengers: string;
    colName: string;
    colContact: string;
    colLocation: string;
    colModel: string;
    colStatus: string;
    colActions: string;
    statusApproved: string;
    statusPending: string;
    statusVerifiedRider: string;
    btnApprove: string;
  };
  footer: {
    desc: string;
    version: string;
    linksPaths: string;
    btnRiderApp: string;
    btnDriverApp: string;
    payScales: string;
    onRoadGuides: string;
    linksLegal: string;
    terms: string;
    safeGuarantee: string;
    privacyCookie: string;
    regulatory: string;
    nativeCta: string;
    nativeDesc: string;
    copyright: string;
    securityBadge: string;
  };
}

export const translations: Record<Language, TranslationDict> = {
  en: {
    dir: 'ltr',
    brand: 'Atlas Ride',
    tagline: 'Android Hub',
    header: {
      features: 'Key Features',
      register: 'Register Profile',
      faq: 'Common FAQs',
      getApp: 'Get Android App',
      androidHub: 'Android Hub',
    },
    hero: {
      badge: 'Android App Hub',
      title1: 'Smart Urban',
      accentTitle: 'Mobility.',
      subtitle: 'The smart, reliable, and secure Android ride-hailing app connecting thousands of daily drivers with passengers. Join our registration portal today to reserve your spot!',
      gps: 'Real-time GPS',
      gpsSub: 'Live tracking',
      safety: 'Verified Safety',
      safetySub: 'SOS & Screening',
      rates: 'Best Rates',
      ratesSub: 'Zero surge trap',
      passengerBtn: 'Passenger Registration',
      driverBtn: 'Drive With Us',
      apkBadge: 'Get the Official Android App',
      storeLabel: 'Download on the',
      storeSub: 'Google Play Store',
      compatibility: 'Compatible with Android 8.0+',
      etaBadge: 'Driver Arriving',
      etaSub: 'ETA: 3 mins away',
      safetyBadge: 'Safe Ride Assured',
      safetySub2: 'PIN matching active',
    },
    features: {
      badge: 'Modern Android Benefits',
      title: 'Engineered for seamless urban transport',
      subtitle: 'Skip the offline hassle. Load up our Android app to access next-gen transport capabilities constructed for drivers and passengers alike.',
      forPassengers: 'For Passengers',
      forDrivers: 'For Drivers',
      passengerItems: [
        {
          title: "Upfront Cost Estimation",
          desc: "Know exactly what your trip costs before booking. No surprise surges, hidden taxes, or tricky meter runs."
        },
        {
          title: "Multi-Destination Stops",
          desc: "Add multiple drop-off points along your route straight from the Android app. Smooth and stress-free."
        },
        {
          title: "SOS Real-time Safety",
          desc: "One-key SOS trigger notifies your emergency contacts and local authorities with your precise GPS coordinates."
        },
        {
          title: "Multi-Channel Payments",
          desc: "Pay with Credit card, Debit card, Cash, Google Pay, or localized Mobile money options on our platform."
        },
        {
          title: "Predictive ETA Logic",
          desc: "Our machine-learning queue matches you with the absolute closest available driver, minimizing wait times to under 4 minutes."
        },
        {
          title: "Custom Vehicle Classes",
          desc: "Choose from Budget Saver, Premium Sedan, spacious XL SUVs, or fast localized Delivery bikes as needed."
        }
      ],
      driverItems: [
        {
          title: "Extremely Low Commissions",
          desc: "Keep up to 88% of your total fares. We believe in sustaining the driving community with a fairer cut."
        },
        {
          title: "Driver-Controlled Hours",
          desc: "Go online and offline strictly when it suits you. Set your custom targets and log off anytime with zero penalty."
        },
        {
          title: "Smart Hotspots & Demand Map",
          desc: "Live interactive thermal map points you towards active heavy-demand zones to find your next trip instantly."
        },
        {
          title: "Safe Passenger Screening",
          desc: "All passengers must authenticate with verified emails/phones. View passenger trip ratings before accepting any ride."
        },
        {
          title: "Weekly Direct Payouts",
          desc: "Receive your accumulated driving earnings directly inside your bank account or wallet every Thursday morning with zero delays."
        },
        {
          title: "Comprehensive Road Assistance",
          desc: "Access premium emergency support, roadside mechanical assistance, and standard driver injury protection plans."
        }
      ]
    },
    register: {
      badge: 'Register & Onboarding Hub',
      title: 'Join our Android Ecosystem',
      subtitle: 'Choose your registration tier below. Your mock credentials populate directly into the temporary Admin Inspector panel so you can review integration states!',
      tabPassenger: 'Register Passenger',
      tabDriver: 'Apply as Driver',
      step1: 'Account Details',
      step2Passenger: 'Payment Preferences',
      step2Driver: 'Vehicle Specifications',
      errorName: 'Full Name is required.',
      errorEmail: 'A valid email address is required.',
      errorPhone: 'A valid phone number is required.',
      errorCity: 'Please specify your operational city.',
      errorModel: 'Please specify your vehicle make & model (e.g. Toyota Prius).',
      errorPlate: 'Please specify your vehicle license plate identifier.',
      errorLicense: 'Please specify your driver license sequence.',
      labelName: 'Full Legal Name',
      placeholderName: 'e.g. Liam Henderson',
      labelEmail: 'Email Address',
      placeholderEmail: 'e.g. liam@example.com',
      labelPhone: 'Mobile Phone Number',
      placeholderPhone: 'e.g. +1 (555) 345-6789',
      phoneHint: 'Include country code for verification SMS triggers.',
      labelCity: 'Operating City',
      placeholderCity: 'e.g. London',
      labelLicense: 'Driver License ID',
      placeholderLicense: 'e.g. DL-9837425',
      labelModel: 'Vehicle Model & Year',
      placeholderModel: 'e.g. Toyota Prius (2022)',
      labelPlate: 'License Plate',
      placeholderPlate: 'e.g. 7XYZ54',
      labelClass: 'Target Transit Class',
      btnNext: 'Continue Step 2',
      paymentLabel: 'Preferred Settlement Method',
      paymentDescCard: 'Secure card storage',
      paymentDescCash: 'Settle directly key-handover',
      paymentDescWallet: 'One-click local wire',
      paymentMethods: {
        card: 'Credit / Debit Card',
        cash: 'Cash',
        wallet: 'Mobile Money Wallet'
      },
      labelReferral: 'Referral Invitation Code (Optional)',
      referralHint: 'Unlock $10 credit to set off your first trip invoice automatically!',
      btnBack: 'Back',
      btnSubmitDriver: 'Submit Application',
      btnSubmitDriverLoading: 'Registering Driver...',
      btnSubmitPassenger: 'Complete Registration',
      btnSubmitPassengerLoading: 'Registering Account...',
      successTitle: 'Registration Confirmed!',
      successDesc: 'Thank you for joining our platform. Your mock registration profile has been persisted inside standard localStorage successfully.',
      successRecord: 'Persistent Record ID',
      successLocal: 'Stored locally',
      roleLabel: 'Role',
      rolePassenger: 'Passenger / Rider',
      roleDriver: 'Pro Driver',
      summaryName: 'Name',
      summaryContact: 'Contact',
      summaryClass: 'Class',
      summaryVehicle: 'Vehicle',
      summarySettle: 'Settle',
      summaryReferral: 'Referral',
      nextStepLabel: 'Next Step: Load App onto Your Android Device',
      nextStepDesc: 'Since this is a static registration site, booking is only available from our native Android packages. Direct download:',
      btnRegAnother: 'Register Another Account'
    },
    faq: {
      badge: 'Frequently Asked Queries',
      title: "Got questions? We've got answers",
      subtitle: 'Everything you need to know about registering as an authorized partner, using premium services on mobile, and keeping your trips secure.',
      catAll: 'Show All FAQs',
      catGeneral: 'General',
      catDriver: 'Drivers Support',
      catPassenger: 'Passengers Support',
      items: [
        {
          category: 'general',
          question: "Which platforms does the app run on?",
          answer: "This is a native Android application engineered exclusively for mobile phones and tablet devices running Android 8.0 Oreo (API level 26) or higher. iOS support is currently under heavy development."
        },
        {
          category: 'passenger',
          question: "Is booking rides supported directly from this website?",
          answer: "No. This website acts as a registration and verification portal for active drivers and users. To secure, map, track, or request an live ride, you must download the native app from the Google Play Store."
        },
        {
          category: 'driver',
          question: "What are the minimum requirements to activate as a driver?",
          answer: "Applicants must be at least 21 years of age, possess a valid localized driver license with at least 1 full year of driving experience, supply an approved vehicle of model year 2012 or newer with up-to-date insurance, and pass standard background verification checks."
        },
        {
          category: 'passenger',
          question: "What payment options are available inside the Android App?",
          answer: "Passengers can pay quickly and safely using standard credit cards, registered debit cards, direct cash handover to the driver, or customized local mobile money options enabled inside your region."
        },
        {
          category: 'driver',
          question: "How long does driver verification and onboarding last?",
          answer: "After you submit your application through this portal, our team completes background record parsing and license validation. Usually, verification takes 24 to 48 business hours, and approvals are notified via email or SMS."
        },
        {
          category: 'general',
          question: "How is user safety ensured during standard trips?",
          answer: "All booked trips feature live, real-time high-resolution GPS telemetry, discrete SOS panic buttons, and trip-sharing codes. Drivers undergo rigorous physical identity checks and vehicle inspections prior to active dispatch."
        }
      ]
    },
    admin: {
      title: 'Client-Side Database Hub',
      desc: 'Review and inspect submitted passenger accounts and driver applications stored in local device persistent memory.',
      btnReset: 'Reset Memory',
      btnInspectorClose: 'Close Registry Inspector',
      btnInspectorOpen: 'Open Live Registry Inspector',
      sandboxed: 'Sandboxed Locally',
      tabDrivers: 'Drivers Applications',
      tabPassengers: 'Registered Passengers',
      noDrivers: 'No driver applications submitted yet. Scroll up to submit a application.',
      noPassengers: 'No passenger registrations submitted yet. Scroll up to submit a application.',
      colName: 'Driver Name / ID',
      colContact: 'Contact Info',
      colLocation: 'City & Model',
      colModel: 'Plate & License',
      colStatus: 'Verification Status',
      colActions: 'Actions',
      statusApproved: 'Active Driver',
      statusPending: 'Pending Review',
      statusVerifiedRider: 'Active Rider',
      btnApprove: 'Approve',
    },
    footer: {
      desc: 'Atlas Ride is a premium high-speed native application for Android environments. This website serves as an onboarding driver registry portal and registration landing zone. It has no booking functionalities, directing active users securely to official package deployment lists on the Play Store.',
      version: 'Build Version: v1.0.8 (Stable API-26+)',
      linksPaths: 'Onboarding Paths',
      btnRiderApp: 'Submit Rider Application',
      btnDriverApp: 'Apply to Drive (Partnership)',
      payScales: 'Browse Driver Pay Scales',
      onRoadGuides: 'Onboarding On-Road Guides',
      linksLegal: 'Legal Compliance',
      terms: 'Driver Terms of Service',
      safeGuarantee: 'Passenger Safe Guarantee',
      privacyCookie: 'Privacy & Cookie Agreement',
      regulatory: 'Licensing & Regulatory Filings',
      nativeCta: 'Deploy Native App',
      nativeDesc: 'Grab the latest optimized Android package file (.apk) directly from our official store pages.',
      copyright: '© 2026 Atlas Ride Transportation Ltd. All mock registry states generated purely for review.',
      securityBadge: 'Atlas Ride Android Security PIN Verification Certified',
    }
  },
  fr: {
    dir: 'ltr',
    brand: 'Atlas Ride',
    tagline: 'Portail Android',
    header: {
      features: 'Caractéristiques',
      register: 'Créer un Profil',
      faq: 'Questions Fréquentes',
      getApp: 'Télécharger l\'Application',
      androidHub: 'Espace Android',
    },
    hero: {
      badge: 'Hub d\'Application Android',
      title1: 'Mobilité Urbaine',
      accentTitle: 'Intelligente.',
      subtitle: 'L\'application Android de covoiturage intelligente, fiable et sécurisée reliant des milliers de chauffeurs quotidiens aux passagers. Rejoignez notre portail d\'inscription dès aujourd\'hui !',
      gps: 'GPS en Temps Réel',
      gpsSub: 'Suivi en direct',
      safety: 'Sécurité Vérifiée',
      safetySub: 'SOS & Filtres',
      rates: 'Meilleurs Tarifs',
      ratesSub: 'Sans majoration abusive',
      passengerBtn: 'Inscription Passager',
      driverBtn: 'Devenir Chauffeur',
      apkBadge: 'Obtenez l\'application Android officielle',
      storeLabel: 'Télécharger sur le',
      storeSub: 'Google Play Store',
      compatibility: 'Compatible avec Android 8.0+',
      etaBadge: 'Arrivée du Chauffeur',
      etaSub: 'Arrivée estimée : 3 min',
      safetyBadge: 'Trajet Sécurisé',
      safetySub2: 'Code PIN de sécurité actif',
    },
    features: {
      badge: 'Avantages Android Modernes',
      title: 'Conçu pour un transport urbain fluide',
      subtitle: 'Évitez les tracas hors ligne. Lancez notre application pour accéder à des services de transport de nouvelle génération adaptés aux chauffeurs et passagers.',
      forPassengers: 'Pour les Passagers',
      forDrivers: 'Pour les Chauffeurs',
      passengerItems: [
        {
          title: "Estimation Initiale du Tarif",
          desc: "Sachez exactement combien coûte votre course avant de réserver. Pas de majorations surprises, de taxes cachées ou de compteurs truqués."
        },
        {
          title: "Arrêts Multiples",
          desc: "Ajoutez plusieurs points de dépose le long de votre itinéraire directement depuis l'application Android. Simple et sans stress."
        },
        {
          title: "Sécurité SOS Temps Réel",
          desc: "Un déclencheur SOS en un clic avertit vos contacts d'urgence et les autorités locales avec vos coordonnées GPS précises."
        },
        {
          title: "Paiements Multi-Canaux",
          desc: "Payez par carte de crédit, carte de débit, espèces, Google Pay ou portefeuille mobile local directement sur notre plateforme."
        },
        {
          title: "Logique ETA Prédictive",
          desc: "Notre file d'attente d'apprentissage automatique vous connecte au chauffeur disponible le plus proche, réduisant l'attente à moins de 4 minutes."
        },
        {
          title: "Classes de Véhicules Personnalisées",
          desc: "Choisissez entre l'Économique, la Berline Premium, les grands SUV XL ou la livraison rapide à moto selon vos besoins."
        }
      ],
      driverItems: [
        {
          title: "Commissions Très Faibles",
          desc: "Conservez jusqu'à 88 % de vos revenus de course. Nous croyons en un soutien équitable et durable pour notre communauté de chauffeurs !"
        },
        {
          title: "Horaires Contrôlés par le Chauffeur",
          desc: "Connectez-vous et déconnectez-vous quand bon vous semble. Fixez vos propres objectifs sans aucune pénalité de présence."
        },
        {
          title: "Zones Chaudes & Carte de Demande",
          desc: "Une carte thermique interactive en temps réel vous oriente directement vers les zones à forte demande pour trouver un client rapidement."
        },
        {
          title: "Filtrage Sécurisé des Passagers",
          desc: "Tous les usagers sont authentifiés par e-mail et téléphone vérifiés. Consultez la note du passager avant d'accepter un trajet."
        },
        {
          title: "Versements Hebdomadaires Directs",
          desc: "Recevez vos revenus de conduite cumulés chaque jeudi matin directement sur votre compte bancaire ou portefeuille mobile sans aucun délai."
        },
        {
          title: "Assistance Routière Complète",
          desc: "Accédez à un support d'urgence premium, une assistance de dépannage mécanique sur route et des plans de couverture d'accident standard."
        }
      ]
    },
    register: {
      badge: 'Hub d\'Inscription & Intégration',
      title: 'Rejoignez notre Écosystème Android',
      subtitle: 'Sélectionnez votre type d\'inscription ci-dessous. Vos identifiants factices remplissent directement le panneau d\'inspection de l\'administrateur pour examiner les données stockées !',
      tabPassenger: 'S\'inscrire comme Passager',
      tabDriver: 'Postuler comme Chauffeur',
      step1: 'Informations de Compte',
      step2Passenger: 'Préférences de Paiement',
      step2Driver: 'Spécifications du Véhicule',
      errorName: 'Le nom complet est obligatoire.',
      errorEmail: 'Une adresse e-mail valide est requise.',
      errorPhone: 'Un numéro de téléphone valide est obligatoire.',
      errorCity: 'Veuillez spécifier votre ville d\'activité.',
      errorModel: 'Veuillez renseigner la marque et le modèle du véhicule (ex: Toyota Prius).',
      errorPlate: 'Veuillez renseigner le numéro d\'immatriculation.',
      errorLicense: 'Veuillez renseigner le numéro de permis de conduire.',
      labelName: 'Nom Complet Légal',
      placeholderName: 'ex: Liam Henderson',
      labelEmail: 'Adresse E-mail',
      placeholderEmail: 'ex: liam@example.com',
      labelPhone: 'Numéro de Téléphone Portable',
      placeholderPhone: 'ex: +33 6 12 34 56 78',
      phoneHint: 'Incluez l\'indicateur pays pour les envois de SMS de validation.',
      labelCity: 'Ville d\'Activité',
      placeholderCity: 'ex: Paris',
      labelLicense: 'N° de Permis de Conduire',
      placeholderLicense: 'ex: PC-9837425',
      labelModel: 'Modèle et Année du Véhicule',
      placeholderModel: 'ex: Toyota Prius (2022)',
      labelPlate: 'Plaque d\'Immatriculation',
      placeholderPlate: 'ex: AB-123-CD',
      labelClass: 'Catégorie de Transport Visée',
      btnNext: 'Continuer vers l\'étape 2',
      paymentLabel: 'Méthode de Paiement Préférée',
      paymentDescCard: 'Stockage de carte hautement sécurisé',
      paymentDescCash: 'Règlement en espèces directement en main propre',
      paymentDescWallet: 'Virement en un clic via portefeuille mobile',
      paymentMethods: {
        card: 'Carte de Crédit / Débit',
        cash: 'Espèces (Direct)',
        wallet: 'Portefeuille Mobile / Paiement local'
      },
      labelReferral: 'Code de Parrainage (Optionnel)',
      referralHint: 'Bénéficiez de 10 $ de réduction crédit directement appliqués sur votre premiere facture !',
      btnBack: 'Retour',
      btnSubmitDriver: 'Soumettre ma Candidature',
      btnSubmitDriverLoading: 'Enregistrement du Chauffeur...',
      btnSubmitPassenger: 'Finaliser l\'Inscription',
      btnSubmitPassengerLoading: 'Création du Compte...',
      successTitle: 'Inscription Confirmée !',
      successDesc: 'Merci d\'avoir rejoint notre plateforme. Votre profil d\'inscription de démonstration a été enregistré localement avec succès dans le localStorage.',
      successRecord: 'N° d\'Enregistrement Persistant',
      successLocal: 'Stocké localement',
      roleLabel: 'Rôle',
      rolePassenger: 'Passager / Client',
      roleDriver: 'Chauffeur Professionnel',
      summaryName: 'Nom',
      summaryContact: 'Contact',
      summaryClass: 'Catégorie',
      summaryVehicle: 'Véhicule',
      summarySettle: 'Règlement',
      summaryReferral: 'Parrainage',
      nextStepLabel: 'Prochaine étape : Installer l\'application sur Android',
      nextStepDesc: 'S\'agissant d\'un site de démonstration, la réservation de trajets s\'effectue uniquement depuis l\'application native. Téléchargement direct :',
      btnRegAnother: 'Créer un autre compte'
    },
    faq: {
      badge: 'Questions Fréquemment Posées',
      title: 'Vous avez des questions ? Nous avons les réponses',
      subtitle: 'Tout ce que vous devez savoir pour vous inscrire en tant que chauffeur partenaire, voyager ou assurer la sécurité de vos trajets.',
      catAll: 'Toutes les questions',
      catGeneral: 'Général',
      catDriver: 'Aide Chauffeurs',
      catPassenger: 'Aide Passagers',
      items: [
        {
          category: 'general',
          question: "Sur quelles plateformes l'application fonctionne-t-elle ?",
          answer: "Il s'agit d'une application Android native conçue exclusivement pour les smartphones et tablettes équipés d'Android 8.0 Oreo (niveau d'API 26) ou supérieur. Le support iOS est en développement."
        },
        {
          category: 'passenger',
          question: "Puis-je commander un trajet directement depuis ce site web ?",
          answer: "Non. Ce site sert uniquement de portail d'inscription et de vérification pour les chauffeurs et les usagers. Pour commander, suivre et payer un trajet en direct, vous devez utiliser l'application mobile disponible sur le Google Play Store."
        },
        {
          category: 'driver',
          question: "Quelles sont les conditions requises pour être chauffeur ?",
          answer: "Vous devez avoir au moins 21 ans, détenir un permis de conduire valide depuis plus d'un an, disposer d'un véhicule approuvé datant de 2012 ou plus récent avec une assurance valide, et réussir une vérification d'antécédents standard."
        },
        {
          category: 'passenger',
          question: "Quelles options de paiement sont prises en charge dans l'application ?",
          answer: "Les passagers peuvent payer rapidement en insérant une carte de crédit/débit, en réglant en espèces directement au chauffeur, ou en payant en un clic avec un portefeuille de monnaie mobile locale réglementé."
        },
        {
          category: 'driver',
          question: "Combien de temps prend le processus de validation de chauffeur ?",
          answer: "Dès soumission de votre dossier via ce portail, notre équipe vérifie vos documents et votre permis de conduire sous 24 à 48 heures ouvrées. Vous recevrez une notification par e-mail et par SMS."
        },
        {
          category: 'general',
          question: "Comment la sécurité est-elle garantie lors des trajets ?",
          answer: "Tous les trajets sont suivis en direct par GPS haute résolution. L'application intègre un bouton d'urgence SOS discret et le partage de trajet temps réel. Nos chauffeurs partenaires font l'objet de contrôles stricts."
        }
      ]
    },
    admin: {
      title: 'Console de Données Localisée',
      desc: 'Consultez et gérez les comptes de voyageurs et les candidatures de chauffeurs stockés localement sur votre navigateur.',
      btnReset: 'Réinitialiser la Mémoire',
      btnInspectorClose: 'Masquer l\'Inspecteur de Base',
      btnInspectorOpen: 'Afficher l\'Inspecteur de Base (Live)',
      sandboxed: 'Isolé localement',
      tabDrivers: 'Candidatures Chauffeurs',
      tabPassengers: 'Passagers Inscrits',
      noDrivers: 'Aucune candidature de chauffeur enregistrée. Utilisez le formulaire pour simuler une inscription.',
      noPassengers: 'Aucun passager enregistré pour le moment. Utilisez le formulaire pour en créer un.',
      colName: 'Nom du Chauffeur / ID',
      colContact: 'Coordonnées de contact',
      colLocation: 'Ville & Modèle',
      colModel: 'Plaque & Permis',
      colStatus: 'Statut de Validation',
      colActions: 'Actions de gestion',
      statusApproved: 'Chauffeur Agréé',
      statusPending: 'Attente d\'Examen',
      statusVerifiedRider: 'Passager Validé',
      btnApprove: 'Valider',
    },
    footer: {
      desc: 'Atlas Ride est une application native de transport fluide et rapide pour écosystèmes Android. Ce site web sert de portail d\'enrôlement et de présentation de l\'application. Il n\'inclut aucune réservation en ligne de trajets et redirige les usagers vers les liens officiels du Google Play Store.',
      version: 'Version Stable : v1.0.8 (API-26+)',
      linksPaths: 'Parcours d\'Inscription',
      btnRiderApp: 'Rejoindre comme Passager',
      btnDriverApp: 'Postuler en Partenariat (Chauffeur)',
      payScales: 'Calculer les commissions chauffeurs',
      onRoadGuides: 'Guides de formation au voyage',
      linksLegal: 'Documents Légaux',
      terms: 'Conditions d\'Utilisation Chauffeurs',
      safeGuarantee: 'Charte de Sécurité Voyageurs',
      privacyCookie: 'Politique de Confidentialité',
      regulatory: 'Licences & Dispositions Légales',
      nativeCta: 'Déployer l\'Application Native',
      nativeDesc: 'Récupérez l\'installateur officiel de l\'application (.apk) directement depuis notre page de distribution.',
      copyright: '© 2026 Atlas Ride Services Ltd. Données persistantes simulées pour des fins de présentation.',
      securityBadge: 'Atlas Ride certifié conforme aux normes de sécurité d\'identification PIN d\'Android',
    }
  },
  ar: {
    dir: 'rtl',
    brand: 'أطلس رايد',
    tagline: 'بوابة أندرويد',
    header: {
      features: 'المزايا الرئيسية',
      register: 'التسجيل في البوابة',
      faq: 'الأسئلة الشائعة',
      getApp: 'تحميل التطبيق',
      androidHub: 'منصة أندرويد',
    },
    hero: {
      badge: 'منصة تطبيق أندرويد الرسمي',
      title1: 'التنقل الحضري',
      accentTitle: 'الذكي.',
      subtitle: 'تطبيق أندرويد الذكي والآمن لتأمين رحلات التوصيل الفورية، يربط آلاف السائقين بالركاب يومياً. انضم إلى بوابة التسجيل اليوم لحجز مكانك مسبقاً!',
      gps: 'تتبع مباشر بـ GPS',
      gpsSub: 'مراقبة فورية للرحلة',
      safety: 'أمان معتمد',
      safetySub: 'فحص الهوية وزر طوارئ',
      rates: 'أفضل الأسعار',
      ratesSub: 'أسعار واضحة وبدون استغلال',
      passengerBtn: 'بوابة تسجيل الركاب',
      driverBtn: 'انضم كشريك سائق',
      apkBadge: 'احصل على تطبيق أندرويد الرسمي الآن',
      storeLabel: 'التحميل من متجر',
      storeSub: 'جوجل بلاي ستور',
      compatibility: 'متوافق مع إصدار أندرويد 8.0 وما فوق',
      etaBadge: 'وصول السائق',
      etaSub: 'وقت الوصول المتوقع: ٣ دقائق فقط',
      safetyBadge: 'رحلة آمنة وموثوقة',
      safetySub2: 'مطابقة رمز الأمان PIN نشطة',
    },
    features: {
      badge: 'امتيازات أندرويد الحديثة',
      title: 'بنية تكنولوجية متطورة لضمان تنقل حضري سلس',
      subtitle: 'تجاوز مشكلات الانتظار التقليدية. قم بتنزيل تطبيقنا للوصول إلى أدوات النقل من الجيل التالي المصممة للسائقين والركاب على حد سواء.',
      forPassengers: 'للركاب والمسافرين',
      forDrivers: 'للشركاء السائقين',
      passengerItems: [
        {
          title: "تقدير التكلفة مسبقاً",
          desc: "اعرف السعر المحدد لرحلتك بشكل مسبق قبل تأكيد الطلب. لا توجد تكاليف خفية، رسوم مفاجئة، أو تلاعب بالعداد."
        },
        {
          title: "محطات توقف متعددة",
          desc: "قم بإضافة عدة محطات لتنزيل الركاب على طول مسار الرحلة مباشرة من خلال واجهة تطبيق أندرويد بشكل سلس وخالٍ من التعقيد."
        },
        {
          title: "نظام الطوارئ الفوري SOS",
          desc: "كبسة زر واحدة لتنبيه جهات الاتصال المحددة لحالات الطوارئ والسلطات المحلية ومشاركتهم بموقعك الجغرافي الدقيق."
        },
        {
          title: "قنوات دفع متعددة ومحلية",
          desc: "ادفع بأمان عبر البطاقات الائتمانية والبنكية، الدفع النقدي (كاش) مباشرة للسائق، أو من خلال المحافظ الإلكترونية المعتمدة."
        },
        {
          title: "توقع ذكي لوقت الوصول ETA",
          desc: "يقوم نظامنا المدعوم بالذكاء الاصطناعي بربطك بأقرب سائق متاح، لتقليل وقت انتظارك لأقل من 4 دقائق في المتوسط."
        },
        {
          title: "خيارات متعددة للمركبات",
          desc: "اختر نوع سيارتك المفضلة بين الفئات الاقتصادية الموفرة، السيارات الفاخرة الممتازة، سيارات الدفع الرباعي الكبيرة العائلية أو خدمات التوصيل السريع."
        }
      ],
      driverItems: [
        {
          title: "عمولات منخفضة للغاية للمنصة",
          desc: "احتفظ بما يصل إلى 88% من إجمالي قيمة أجرة الرحلة. نحن نؤمن بأن حصولك على النسبة الأكبر يدعم الاستدامة ويساند شركاءنا."
        },
        {
          title: "مرونة كاملة وتحديد ساعات العمل",
          desc: "ابدأ العمل على التطبيق واذهب للراحة متى ما شئت. حدد أهدافك المالية اليومية الخاصة وقم بتسجيل الخروج بدون أدنى غرامة."
        },
        {
          title: "المناطق الساخنة وتوزيع الطلبات",
          desc: "خارطة حرارية تفاعلية ومؤشرات حية ترشدك فوراً لأماكن الكثافة السكانية ومناطق الطلب المتزايد لتحقيق أعلى دخل ممكن."
        },
        {
          title: "فرز الركاب والتحقق من الهوية",
          desc: "جميع الركاب لدينا يمتلكون حسابات موثقة بالبريد والهاتف الجوال. اطلع على تقييم الراكب وملاحظات السائقين الآخرين قبل قبول الرحلة."
        },
        {
          title: "مستحقات وأرباح أسبوعية مباشرة",
          desc: "احصل على كامل أرباحك وعوائدك المتراكمة مباشرة في حسابك البنكي أو محفظتك الإلكترونية صباح كل خميس دون أدنى تأخير."
        },
        {
          title: "دعم مخصص ومساعدة على الطريق",
          desc: "تواصل مع خط الدعم الساخن المخصص للسائقين على مدار الساعة لتلقي الدعم الميكانيكي والفني، وباقات التأمين الصحي عند الحوادث."
        }
      ]
    },
    register: {
      badge: 'بوابة إدراج وتسجيل البيانات',
      title: 'انضم إلى منظومتنا المتكاملة على أندرويد',
      subtitle: 'اختر الفئة التي تريد التسجيل بها أدناه. ستظهر بياناتك المسجلة تلقائياً في لوحة تحكم الإدارة المرفقة بالبرمجية من أجل المراجعة السريعة لبيانات التخزين !',
      tabPassenger: 'تسجيل حساب راكب',
      tabDriver: 'تقديم طلب سائق',
      step1: 'معلومات الحساب الأساسية',
      step2Passenger: 'طرق الدفع المفضلة',
      step2Driver: 'مواصفات المركبة وبيانات الترخيص',
      errorName: 'يُرجى إدخال الاسم الكامل القانوني بشكل صحيح.',
      errorEmail: 'يُرجى إدخال بريد إلكتروني صحيح وموثق.',
      errorPhone: 'يُرجى إدخال رقم هاتفك الجوال بشكل صحيح.',
      errorCity: 'يُرجى تحديد مدينة العمل الأساسية الخاصة بك.',
      errorModel: 'يُرجى تحديد طراز سيارتك وسنة الصنع (مثال: تويوتا بريوس ٢٠٢٢).',
      errorPlate: 'يُرجى إدخال رقم لوحة السيارة والترميز.',
      errorLicense: 'يُرجى إدخال رقم رخصة القيادة السارية.',
      labelName: 'الاسم الكامل الموثق',
      placeholderName: 'مثال: كريم الأحمد',
      labelEmail: 'البريد الإلكتروني',
      placeholderEmail: 'مثال: kareem@example.com',
      labelPhone: 'رقم الهاتف الجوال للمطابقة',
      placeholderPhone: 'مثال: +966 50 123 4567',
      phoneHint: 'يرجى كتابة رمز الدولة بشكل صحيح لاستقبال رسائل رمز التفعيل SMS.',
      labelCity: 'مدينة العمل والنشاط',
      placeholderCity: 'مثال: الرياض',
      labelLicense: 'رقم رخصة القيادة',
      placeholderLicense: 'مثال: LIC-9837425',
      labelModel: 'طراز المركبة وسنة الصنع',
      placeholderModel: 'مثال: تويوتا كامري (٢٠٢٢)',
      labelPlate: 'رقم لوحة السيارة',
      placeholderPlate: 'مثال: أ ب ج ١٢٣٤',
      labelClass: 'فئة التوصيل الأنسب للمركبة',
      btnNext: 'الانتقال للخطوة الثانية',
      paymentLabel: 'طريقة الدفع والتسوية المفضلة',
      paymentDescCard: 'حفظ مستندات البطاقة بأمان تام وقنوات مشفرة',
      paymentDescCash: 'الدفع نقداً بنهاية كل رحلة مباشرة للسائق اليد باليد',
      paymentDescWallet: 'تحويل مالي فوري بكبسة زر للمحفظة الإلكترونية',
      paymentMethods: {
        card: 'بطاقة مدى / البطاقة الائتمانية',
        cash: 'الدفع نقداً (كاش)',
        wallet: 'المحفظة الإلكترونية / الخدمات المحلية'
      },
      labelReferral: 'رمز الإحالة والدعوة الترويجية (اختياري)',
      referralHint: 'احصل على رصيد ترويجي بقيمة ١٠ دولارات يتم خصمه تلقائياً من فاتورة رحلتك الأولى مع المنصة !',
      btnBack: 'رجوع للخلف',
      btnSubmitDriver: 'إرسال طلب الانضمام كشريك',
      btnSubmitDriverLoading: 'جاري مراجعة وحفظ طلب السائق...',
      btnSubmitPassenger: 'إكمال تأسيس حساب الراكب',
      btnSubmitPassengerLoading: 'جاري إنشاء وتفعيل الحساب التوضيحي...',
      successTitle: 'تم تأكيد طلب التسجيل بنجاح !',
      successDesc: 'شكراً لانضمامك إلينا كشريك معتمد. تم تخزين كافة بيانات حسابك التجريبي في الذاكرة المحلية للمتصفح (localStorage) بأمان بنجاح.',
      successRecord: 'رقم السجل الثابت',
      successLocal: 'مخزن محلياً بالكامل',
      roleLabel: 'الصفة الوظيفية للمسجل',
      rolePassenger: 'مسافر / راكب معتمد',
      roleDriver: 'سائق محترف شريك',
      summaryName: 'الاسم الكامل',
      summaryContact: 'الاتصال',
      summaryClass: 'الفئة',
      summaryVehicle: 'المركبة والمعلومات',
      summarySettle: 'التسوية والمالية',
      summaryReferral: 'رمز الدعوة الإضافي',
      nextStepLabel: 'الخطوة التالية: تشغيل التطبيق الرسمي لطلب الرحلات على أندرويد',
      nextStepDesc: 'بما أن هذا الموقع هو بوابة ترحيبية وتسجيلية فقط، فإن حجز ومطابقة السائقين متاح حصرياً عبر التطبيق الأساسي لأندرويد. التحميل المباشر:',
      btnRegAnother: 'تسجيل حساب توضيحي آخر'
    },
    faq: {
      badge: 'الأسئلة الأكثر شيوعاً واستفساراً',
      title: 'لديك استفسار؟ لدينا إجابات كافية',
      subtitle: 'كل ما تحتاج لمعرفته حول التسجيل في أطلس رايد كشريك وسائق، إجراءات الأمان للركاب، والتحقق المستمر لرحلات آمنة.',
      catAll: 'عرض الكل',
      catGeneral: 'عام',
      catDriver: 'شؤون السائقين',
      catPassenger: 'دعم الركاب والمشتركين',
      items: [
        {
          category: 'general',
          question: "ما هي أنظمة التشغيل والمنصات المدعومة للتطبيق؟",
          answer: "التطبيق عبارة عن برمجية وتطبيق أندرويد أصلي (Native App) تم تصميمه وتطويره حصرياً للعمل على كافة الهواتف واللوائح الذكية التي تتبنى نظام أندرويد ٨.٠ أو أعلى. وتطوير نسخة الـ iOS حالياً جاري العمل عليه بجدية."
        },
        {
          category: 'passenger',
          question: "هل يمكنني طلب رحلة وحجز سائق حقيقي مباشرة من هذا الموقع؟",
          answer: "لا، هذا الموقع هو واجهة ويب وبوابة للتسجيل المبدئي للراكبين وتلقي وفرز طلبات الشراكة من السائقين لتأهيلهم. لإتمام العمليات ومراقبة الخارطة وحجز تاكسي، يجب تنزيل التطبيق للهاتف المحمول من جوجل بلاي ستور."
        },
        {
          category: 'driver',
          question: "ما هي الشروط الأبرز لقبول طلبات وتأهيل السائقين؟",
          answer: "يجب ألا يقل عمر المتقدم عن ٢١ عاماً، مع امتلاك رخصة قيادة وطنية سارية المفعول مضى على إصدارها سنة على الأقل، وسجل سليم خالٍ من المخالفات الجسيمة، بالإضافة إلى سيارة عائلية أو متوسطة من موديل سنة ٢٠١٢ فما فوق ممتدة التأمين."
        },
        {
          category: 'passenger',
          question: "ما هي وسائل الدفع وطرق التسوية المتاحة للرحلة؟",
          answer: "يمتلك الراكب مرونة بالغة بالاختيار بين الدفع فوراً عبر البطاقة المسجلة في التطبيق، أو الدفع كاش مباشرة بإنهاء الرحلة للسائق، أو من خلال المحفظة الإلكترونية المعززة محلياً للدفع الإلكتروني السريع."
        },
        {
          category: 'driver',
          question: "كم تستغرق عملية مراجعة طلبي وتأهيلي للعمل وتلقي الركاب؟",
          answer: "بعد تقديم طلبك من خلال هذه المنصة، تتولى فرق التوثيق فحص الرخصة والتحقق من الأوراق الرسمية في مدة لا تتجاوز ٢٤ إلى ٤٨ ساعة عمل، وسيتم إعلامك بالقبول الفوري ببرقية بريد أو رسالة نصية SMS."
        },
        {
          category: 'general',
          question: "كيف يتم توفير وضمان بيئة آمنة للركاب والسائقين في الطرق؟",
          answer: "تخضع جميع الرحلات العاملة لتتبع مستمر على الخارطة عبر الـ GPS بدقة عالية، وتمتد لتشمل زراً صامتاً ومباشراً للحماية SOS لمشاركة الموقع الفوري مع الشرطة أو الطوارئ، بالإضافة إلى شرط مطابقة الرمز الثنائي PIN قبل الصعود."
        }
      ]
    },
    admin: {
      title: 'قاعدة البيانات ومستودع السجلات المحلي (تجريبي)',
      desc: 'سجل مباشر للمراقبة الداخلية وتدقيق بيانات حسابات الركاب المسجلين وتطبيقات السائقين التوضيحية والمنفذة في متصفحك.',
      btnReset: 'تفريغ وتنظيف قاعدة البيانات ومستودع الذاكرة',
      btnInspectorClose: 'إخفاء لوحة مراجعة السجلات',
      btnInspectorOpen: 'فتح لوحة مراجعة السجلات والبيانات المباشرة',
      sandboxed: 'محمي ومخزن بالكامل في متصفحك محلياً',
      tabDrivers: 'قائمة عروض السائقين الجدد',
      tabPassengers: 'سجلات الركاب المفعلين',
      noDrivers: 'لم يتم استلام أي طلب شراكة لسائق حتى الآن. يرجى ملء النموذج العلوي لتسجيل بياناتك.',
      noPassengers: 'لا توجد سجلات ركاب نشطة حالياً بقاعدة البيانات. قم بملء النموذج للتسجيل كراكب لعرضه هنا.',
      colName: 'اسم السائق / رقم السجل',
      colContact: 'بيانات الاتصال والتراسل',
      colLocation: 'المدينة والسيارة المتوفرة',
      colModel: 'رقم اللوحة والتراخيص الموثقة',
      colStatus: 'الحالة وتأهيل الطلب',
      colActions: 'إجراءات الإدارة والمراجعة',
      statusApproved: 'سائق شريك نشط',
      statusPending: 'قيد مراجعة السندات',
      statusVerifiedRider: 'راكب معتمد بالبوابة',
      btnApprove: 'قبول وتأهيل الشريك السائق عاجلاً',
    },
    footer: {
      desc: 'أطلس رايد هي بوابة الترحيب الرسمية ومنصة إدراج ركاب وشركاء سائقين لتطبيق أندرويد الأصلي لخدمات التنقل السريع. تم تصميم هذا الموقع للتعريف بالتطبيق واستقطاب الكوادر السائقة وتسهيل الحصول على حزم التطبيق الرسمية من متجر جوجل Play Store.',
      version: 'إصدار البرمجية الحالي: v1.0.8 (مستقر API-26)',
      linksPaths: 'أقسام وخرائط البوابة المتاحة',
      btnRiderApp: 'إدراج طلب راكب تجريبي',
      btnDriverApp: 'تقديم طلب الانضمام كشريك تاكسي',
      payScales: 'توزيع العمولات وحساب الأرباح',
      onRoadGuides: 'إرشاد القيادة والسلامة المتبعة',
      linksLegal: 'الاتفاقيات القانونية والخصوصية',
      terms: 'اتفاقية شروط وأحكام الشركاء السائقين',
      safeGuarantee: 'ميثاق ضمان سلامة الركاب والعملاء',
      privacyCookie: 'حقوق الخصوصية وملفات الاستهداف',
      regulatory: 'التراخيص الوطنية والأوراق الحكومية',
      nativeCta: 'قم بتثبيت التطبيق على أندرويد',
      nativeDesc: 'احصل على ملف تثبيت البرنامج الأصلي والتلقائي الفوري (.apk) لهاتفك الجوال من واجهة المستودع والمنصات.',
      copyright: '© ٢٠٢٦ شركة أطلس رايد لخدمات وتسهيلات النقل المحدودة. كافة البيانات تجريبية بالكامل.',
      securityBadge: 'برنامج أطلس رايد مدعوم ومطابق بالكامل لمعايير الحماية والأمان لنظام جوجل أندرويد PIN.',
    }
  }
};
