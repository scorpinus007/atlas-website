export interface RegisteredDriver {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  vehicleType: 'economy' | 'premium' | 'xl' | 'delivery';
  vehicleModel: string;
  licensePlate: string;
  licenseNumber: string;
  registeredAt: string;
  status: 'pending_review' | 'approved';
}

export interface RegisteredPassenger {
  id: string;
  name: string;
  email: string;
  phone: string;
  preferredPayment: 'card' | 'cash' | 'mobile_wallet';
  referralCode?: string;
  registeredAt: string;
  status: 'active';
}

export interface FaqItem {
  question: string;
  answer: string;
  category: 'driver' | 'passenger' | 'general';
}
